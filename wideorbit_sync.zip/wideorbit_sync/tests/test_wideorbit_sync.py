import base64
import io
from unittest.mock import patch, MagicMock
from odoo.tests.common import TransactionCase

try:
    from openpyxl import Workbook
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False


class TestWideOrbitSync(TransactionCase):

    def setUp(self):
        super(TestWideOrbitSync, self).setUp()
        
        # Skip tests if openpyxl is not available in the test environment
        if not OPENPYXL_AVAILABLE:
            self.skipTest("openpyxl is not installed in the environment.")

        # Rename the existing main test company to match the test billing group
        self.company = self.env.company
        self.company.write({'name': 'Test Billing Group'})
        
        # Find or create a sales journal for the company
        self.journal = self.env['account.journal'].search([
            ('type', '=', 'sale'),
            ('company_id', '=', self.company.id)
        ], limit=1)
        if not self.journal:
            self.journal = self.env['account.journal'].create({
                'name': 'Test Sales Journal',
                'type': 'sale',
                'code': 'TSALE',
                'company_id': self.company.id
            })
        
        account_model = self.env['account.account']
        company_field = 'company_ids' if 'company_ids' in account_model._fields else 'company_id'
        
        # Find if account 1550 already exists, otherwise create it
        self.account = account_model.search([
            ('code', '=', '1550'),
            (company_field, '=', self.company.id)
        ], limit=1)
        
        if not self.account:
            account_vals = {
                'name': 'Test Revenue',
                'code': '1550',
                'account_type': 'income',
            }
            if company_field == 'company_ids':
                account_vals['company_ids'] = [(6, 0, [self.company.id])]
            else:
                account_vals['company_id'] = self.company.id
            self.account = account_model.create(account_vals)

        # Resolve the selection list helper safely (selection can be a list or a callable)
        account_type_selection = account_model._fields['account_type'].selection
        if callable(account_type_selection):
            selection_keys = [k for k, v in account_type_selection(self.env)]
        else:
            selection_keys = [k for k, v in account_type_selection]

        # Ensure default receivable account exists for the company
        self.receivable_account = account_model.search([
            ('account_type', 'in', ('asset_receivable', 'receivable')),
            (company_field, '=', self.company.id)
        ], limit=1)
        if not self.receivable_account:
            acc_type = 'asset_receivable' if 'asset_receivable' in selection_keys else 'receivable'
            vals = {
                'name': 'Test Receivable Account',
                'code': '1200',
                'account_type': acc_type,
            }
            if company_field == 'company_ids':
                vals['company_ids'] = [(6, 0, [self.company.id])]
            else:
                vals['company_id'] = self.company.id
            self.receivable_account = account_model.create(vals)

        # Ensure default payable account exists for the company
        self.payable_account = account_model.search([
            ('account_type', 'in', ('liability_payable', 'payable')),
            (company_field, '=', self.company.id)
        ], limit=1)
        if not self.payable_account:
            acc_type = 'liability_payable' if 'liability_payable' in selection_keys else 'payable'
            vals = {
                'name': 'Test Payable Account',
                'code': '2200',
                'account_type': acc_type,
            }
            if company_field == 'company_ids':
                vals['company_ids'] = [(6, 0, [self.company.id])]
            else:
                vals['company_id'] = self.company.id
            self.payable_account = account_model.create(vals)

    def _create_excel_base64(self, headers, rows, sheet_name=None):
        wb = Workbook()
        if sheet_name:
            ws = wb.active
            ws.title = sheet_name
        else:
            ws = wb.active
        
        ws.append(headers)
        for r in rows:
            ws.append(r)
        
        fp = io.BytesIO()
        wb.save(fp)
        fp.seek(0)
        return base64.b64encode(fp.read())

    def test_wideorbit_sync_flow(self):
        from unittest.mock import patch

        # 1. Create Mock Workbook
        wb = Workbook()
        
        # Agency sheet
        ws_agency = wb.create_sheet(title='Agency')
        ws_agency.append(['Agency Name', 'RPA_Address Line 1', 'RPA_City, State  Zip Code', 'RPA_Phone', 'RPA_Statement Email', 'RPA_Country', 'API_AGENCY_ID'])
        ws_agency.append(['Test Agency', '123 Main St', 'Secaucus, NJ  07094', '555-0101', 'agency@test.com', 'US', 'AG-01'])
        
        # Advertiser sheet
        ws_adv = wb.create_sheet(title='Advertiser')
        ws_adv.append(['Advertiser Name', 'RPA_Address Line 1', 'RPA_City, State  Zip Code', 'RPA_Phone', 'RPA_Statement Email', 'RPA_Country', 'API_ADVERTISER_ID'])
        ws_adv.append(['Test Advertiser', '456 Elm St', 'Miami, FL  33181', '555-0202', 'advertiser@test.com', 'US', 'AD-01'])
        
        # Invoice sheet
        ws_inv = wb.create_sheet(title='Invoice')
        ws_inv.append([
            'Invoice Number', 'RPA_Agency', 'RPA_Advertiser', 'API_API_INVOICE_ID', 
            'RPA_Billing Group', 'API_NET_AMOUNT', 'RPA_# Spots', 'API_INVOICE_DATE', 
            'API_DUE_DATE', 'RPA_Order Product Description', 'API_OUTSTANDING_AMOUNT'
        ])
        ws_inv.append([
            'INV-1001', 'Test Agency', 'Test Advertiser', 'WO-INV-1001', 
            'Test Billing Group', 1000.0, 10, '2026-07-08', 
            '2026-08-08', 'Test Product Description', 0.0
        ])
        
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])

        # 2. Create Dummy Config
        config = self.env['wideorbit.source.config'].create({
            'name': 'Test Config',
            'sp_rpa_folder': '/RPA',
            'sp_api_folder': '/API',
        })

        # 3. Instantiate Wizard
        wizard = self.env['wideorbit.sync'].create({
            'source_config_id': config.id,
        })

        # 4. Trigger Sync with mocked workbook object returning from remote and mocked fetcher
        mock_fetcher = MagicMock()
        mock_fetcher.connect.return_value = True

        with patch('odoo.addons.wideorbit_sync.models.wideorbit_source_config.WideOrbitSourceConfig._get_fetcher', return_value=mock_fetcher), \
             patch('odoo.addons.wideorbit_sync.models.wideorbit_master_workbook.WideOrbitMasterWorkbook._generate_workbook_object', return_value=wb):
            wizard.action_run_sync()

        # 5. Assertions
        # Check Agency
        agency_partner = self.env['res.partner'].search([('wideorbit_agency_id', '=', 'AG-01')])
        self.assertTrue(agency_partner, "Agency partner should have been created.")
        self.assertEqual(agency_partner.email, 'agency@test.com')
        self.assertEqual(agency_partner.city, 'Secaucus')
        self.assertEqual(agency_partner.zip, '07094')
        self.assertTrue(agency_partner.is_company)

        # Check Advertiser
        advertiser_partner = self.env['res.partner'].search([('wideorbit_advertiser_id', '=', 'AD-01')])
        self.assertTrue(advertiser_partner, "Advertiser partner should have been created.")
        self.assertEqual(advertiser_partner.email, 'advertiser@test.com')
        self.assertEqual(advertiser_partner.city, 'Miami')
        self.assertEqual(advertiser_partner.zip, '33181')
        self.assertTrue(advertiser_partner.is_company)
        self.assertEqual(advertiser_partner.parent_id.id, agency_partner.id, "Advertiser should be linked to Agency as child.")

        # Check Invoice
        invoice = self.env['account.move'].search([('wideorbit_invoice_id', '=', 'WO-INV-1001')])
        self.assertTrue(invoice, "Invoice should have been created.")
        self.assertEqual(invoice.ref, 'INV-1001')
        self.assertEqual(invoice.partner_id.id, advertiser_partner.id)
        self.assertEqual(invoice.company_id.id, self.company.id)
        # Note: in testing environment, action_post might fail if no sequences or general configuration is set.
        # But we verify it was processed. Let's assert it has 1 line.
        self.assertEqual(len(invoice.invoice_line_ids), 1)
        self.assertEqual(invoice.invoice_line_ids[0].quantity, 1.0)
        self.assertEqual(invoice.invoice_line_ids[0].price_unit, 1000.0)

        # Check Sync Audit Logs
        log = self.env['wideorbit.sync.log'].search([], limit=1)
        self.assertTrue(log)
        self.assertEqual(log.status, 'success')
        self.assertEqual(log.invoices_processed, 1)
        self.assertEqual(log.invoices_created, 1)
        self.assertEqual(log.invoices_updated, 0)
        self.assertEqual(log.invoices_skipped, 0)
        self.assertEqual(log.agencies_created, 1)
        self.assertEqual(log.agencies_updated, 0)
        self.assertEqual(log.agencies_skipped, 0)
        self.assertEqual(log.advertisers_created, 1)
        self.assertEqual(log.advertisers_updated, 0)
        self.assertEqual(log.advertisers_skipped, 0)
        
        # Verify Many2many relationships linked the synced records
        self.assertEqual(len(log.synced_invoice_ids), 1)
        self.assertEqual(len(log.synced_agency_ids), 1)
        self.assertEqual(len(log.synced_advertiser_ids), 1)
