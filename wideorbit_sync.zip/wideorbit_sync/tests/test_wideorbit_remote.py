# -*- coding: utf-8 -*-
import base64
import io
import json
from unittest.mock import patch, MagicMock
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError

try:
    from openpyxl import Workbook
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False


class TestWideOrbitRemoteSync(TransactionCase):

    def setUp(self):
        super(TestWideOrbitRemoteSync, self).setUp()
        if not OPENPYXL_AVAILABLE:
            self.skipTest("openpyxl is not installed in the environment.")

        # Setup standard company details
        self.company = self.env.company
        self.company.write({'name': 'Test Remote Company'})

        # Find or create a sales journal for the company
        self.journal = self.env['account.journal'].search([
            ('type', '=', 'sale'),
            ('company_id', '=', self.company.id)
        ], limit=1)
        if not self.journal:
            self.journal = self.env['account.journal'].create({
                'name': 'Test Sales Journal',
                'type': 'sale',
                'code': 'TRSAL',
                'company_id': self.company.id
            })

        account_model = self.env['account.account']
        company_field = 'company_ids' if 'company_ids' in account_model._fields else 'company_id'

        # Ensure account 1550 exists
        self.account = account_model.search([
            ('code', '=', '1550'),
            (company_field, '=', self.company.id)
        ], limit=1)
        if not self.account:
            account_vals = {
                'name': 'Test Revenue',
                'code': '1550',
                'account_type': 'income',
            }
            if company_field == 'company_ids':
                account_vals['company_ids'] = [(6, 0, [self.company.id])]
            else:
                account_vals['company_id'] = self.company.id
            self.account = account_model.create(account_vals)

        # Resolve the selection list helper safely (selection can be a list or a callable)
        account_type_selection = account_model._fields['account_type'].selection
        if callable(account_type_selection):
            selection_keys = [k for k, v in account_type_selection(self.env)]
        else:
            selection_keys = [k for k, v in account_type_selection]

        # Ensure default receivable account exists for the company
        self.receivable_account = account_model.search([
            ('account_type', 'in', ('asset_receivable', 'receivable')),
            (company_field, '=', self.company.id)
        ], limit=1)
        if not self.receivable_account:
            acc_type = 'asset_receivable' if 'asset_receivable' in selection_keys else 'receivable'
            vals = {
                'name': 'Test Receivable Account',
                'code': '1200',
                'account_type': acc_type,
            }
            if company_field == 'company_ids':
                vals['company_ids'] = [(6, 0, [self.company.id])]
            else:
                vals['company_id'] = self.company.id
            self.receivable_account = account_model.create(vals)

        # Ensure default payable account exists for the company
        self.payable_account = account_model.search([
            ('account_type', 'in', ('liability_payable', 'payable')),
            (company_field, '=', self.company.id)
        ], limit=1)
        if not self.payable_account:
            acc_type = 'liability_payable' if 'liability_payable' in selection_keys else 'payable'
            vals = {
                'name': 'Test Payable Account',
                'code': '2200',
                'account_type': acc_type,
            }
            if company_field == 'company_ids':
                vals['company_ids'] = [(6, 0, [self.company.id])]
            else:
                vals['company_id'] = self.company.id
            self.payable_account = account_model.create(vals)

        # Setup configuration
        self.config = self.env['wideorbit.source.config'].create({
            'name': 'Test Remote Sync Config',
            'data_source': 'sharepoint',
            'sp_tenant_id': 'test-tenant',
            'sp_client_id': 'test-client',
            'sp_client_secret': 'test-secret',
            'sp_site_domain': 'test.sharepoint.com',
            'sp_site_path': '/sites/test',
            'sp_rpa_folder': '/RPA',
            'sp_api_folder': '/API',
            'sp_pdf_subfolder': 'INVOICE_PDF',
        })

    def _create_excel_bytes(self, headers, rows, sheet_name=None):
        wb = Workbook()
        ws = wb.active
        if sheet_name:
            ws.title = sheet_name
        ws.append(headers)
        for r in rows:
            ws.append(r)
        fp = io.BytesIO()
        wb.save(fp)
        fp.seek(0)
        return fp.read()

    @patch('requests.post')
    @patch('requests.get')
    def test_remote_sync_flow_api_csv(self, mock_get, mock_post):
        # 1. Mock Access Token OAuth request
        mock_post_resp = MagicMock()
        mock_post_resp.status_code = 200
        mock_post_resp.json.return_value = {"access_token": "mock_access_token"}
        mock_post.return_value = mock_post_resp

        # 2. Mock Graph API calls for Site ID, Drive ID, Children List, and File Downloads
        # Prepare CSV data
        agency_csv = "Agency,Address Line 1,\"City, State  Zip Code\",Phone,Statement Email,Country\nTest Agency,123 Main St,\"Secaucus, NJ  07094\",555-0101,agency@test.com,US\n"
        advertiser_csv = "Advertiser,Address Line 1,\"City, State  Zip Code\",Phone,Statement Email,Country\nTest Advertiser,456 Elm St,\"Miami, FL  33181\",555-0202,advertiser@test.com,US\n"
        invoice_csv = (
            "Invoice #,Agency Name (Mapped),Agency ID (Mapped),Advertiser Name (Mapped),Advertiser ID (Mapped),INVOICE_ID (Mapped),Billing Group,Net $,Invoice Date,Due Date,Order Product Description,Balance\n"
            "INV-2001,Test Agency,AG-02,Test Advertiser,AD-02,WO-INV-2001,Test Remote Company,1200.00,2026-07-08,2026-08-08,Product Descr,0.0\n"
        )
        pdf_bytes = b"%PDF-1.4 mock content"

        # Prepare RPA files
        rpa_inv = self._create_excel_bytes(
            ['Invoice #', 'Agency Name (Mapped)', 'Advertiser Name (Mapped)', 'Net $', 'Balance'],
            [['INV-2001', 'Test Agency', 'Test Advertiser', 1200.00, 0.0]],
            'Invoice'
        )
        rpa_agency = self._create_excel_bytes(
            ['Agency Name (Mapped)', 'Address Line 1', 'City, State  Zip Code', 'Phone', 'Statement Email', 'Country'],
            [['Test Agency', '123 Main St', 'Secaucus, NJ  07094', '555-0101', 'agency@test.com', 'US']],
            'Agency'
        )
        rpa_adv = self._create_excel_bytes(
            ['Advertiser Name (Mapped)', 'Address Line 1', 'City, State  Zip Code', 'Phone', 'Statement Email', 'Country'],
            [['Test Advertiser', '456 Elm St', 'Miami, FL  33181', '555-0202', 'advertiser@test.com', 'US']],
            'Advertiser'
        )

        def side_effect_get(url, **kwargs):
            resp = MagicMock()
            resp.status_code = 200
            url_lower = url.lower()

            if "sites/test.sharepoint.com" in url_lower:
                # Site ID resolution
                resp.json.return_value = {"id": "resolved_site_id"}
            elif "sites/resolved_site_id/drive" in url_lower:
                # Drive ID resolution
                resp.json.return_value = {"id": "resolved_drive_id"}
            elif "root:/api:/children" in url_lower:
                # List API folder files
                resp.json.return_value = {
                    "value": [
                        {"name": "Invoices.csv", "size": len(invoice_csv)},
                        {"name": "Agencies.csv", "size": len(agency_csv)},
                        {"name": "Advertisers.csv", "size": len(advertiser_csv)},
                    ]
                }
            elif "root:/rpa:/children" in url_lower:
                # List RPA folder files
                resp.json.return_value = {
                    "value": [
                        {"name": "Invoices.xlsx", "size": len(rpa_inv)},
                        {"name": "Agencies.xlsx", "size": len(rpa_agency)},
                        {"name": "Advertisers.xlsx", "size": len(rpa_adv)},
                    ]
                }
            elif "root:/rpa/invoice_pdf:/children" in url_lower:
                # List PDF folder files
                resp.json.return_value = {
                    "value": [
                        {"name": "INV-2001.pdf", "size": len(pdf_bytes)},
                        {"name": "Unrelated.pdf", "size": len(pdf_bytes)},
                    ]
                }
            elif "invoices.xlsx:/content" in url_lower:
                resp.content = rpa_inv
            elif "agencies.xlsx:/content" in url_lower:
                resp.content = rpa_agency
            elif "advertisers.xlsx:/content" in url_lower:
                resp.content = rpa_adv
            elif "invoices.csv:/content" in url_lower:
                resp.content = invoice_csv.encode('utf-8')
            elif "agencies.csv:/content" in url_lower:
                resp.content = agency_csv.encode('utf-8')
            elif "advertisers.csv:/content" in url_lower:
                resp.content = advertiser_csv.encode('utf-8')
            elif "inv-2001.pdf:/content" in url_lower:
                resp.content = pdf_bytes
            else:
                resp.status_code = 404
                resp.text = "Not Found"
            return resp

        mock_get.side_effect = side_effect_get

        # 3. Instantiate Wizard and Trigger Sync
        wizard = self.env['wideorbit.sync'].create({
            'source_config_id': self.config.id,
        })
        wizard.action_run_sync()

        # 4. Verify entities created
        agency = self.env['res.partner'].search([('wideorbit_agency_id', '=', 'AG-02')], limit=1)
        self.assertTrue(agency, "Agency should be created.")
        self.assertEqual(agency.email, 'agency@test.com')
        self.assertEqual(agency.city, 'Secaucus')

        advertiser = self.env['res.partner'].search([('wideorbit_advertiser_id', '=', 'AD-02')], limit=1)
        self.assertTrue(advertiser, "Advertiser should be created.")
        self.assertEqual(advertiser.parent_id.id, agency.id, "Advertiser parent should be the matched Agency.")

        invoice = self.env['account.move'].search([('wideorbit_invoice_id', '=', 'WO-INV-2001')], limit=1)
        self.assertTrue(invoice, "Invoice should be created.")
        self.assertEqual(invoice.ref, 'INV-2001')
        self.assertTrue(invoice.state in ('posted', 'draft'), "Invoice should be created in posted or draft state.")

        # Verify PDF attachment
        attachment = self.env['ir.attachment'].search([
            ('res_model', '=', 'account.move'),
            ('res_id', '=', invoice.id),
            ('name', '=', 'INV-2001.pdf')
        ], limit=1)
        self.assertTrue(attachment, "PDF attachment should be linked to the Odoo invoice.")
        self.assertEqual(base64.b64decode(attachment.datas), pdf_bytes)

    @patch('requests.post')
    @patch('requests.get')
    def test_master_workbook_generation(self, mock_get, mock_post):
        # 1. Mock Access Token
        mock_post_resp = MagicMock()
        mock_post_resp.status_code = 200
        mock_post_resp.json.return_value = {"access_token": "mock_access_token"}
        mock_post.return_value = mock_post_resp

        # 2. Mock Site ID, Drive ID, and File listings/contents
        # Prepare RPA files
        rpa_inv = self._create_excel_bytes(
            ['Invoice #', 'Agency Name (Mapped)', 'Advertiser Name (Mapped)', 'Net $', 'Balance'],
            [['INV-2001', 'Agency A', 'Advertiser A', 150.00, 0.0]],
            'Invoice'
        )
        rpa_agency = self._create_excel_bytes(
            ['Agency Name (Mapped)', 'Address Line 1', 'City, State  Zip Code'],
            [['Agency A', '123 Main St', 'Secaucus, NJ  07094']],
            'Agency'
        )
        rpa_adv = self._create_excel_bytes(
            ['Advertiser Name (Mapped)', 'Address Line 1', 'City, State  Zip Code'],
            [['Advertiser A', '456 Elm St', 'Miami, FL  33181']],
            'Advertiser'
        )

        # Prepare API files
        api_inv = "Invoice #,Agency Name (Mapped),Advertiser Name (Mapped),Net $,Balance\nINV-2001,Agency A,Advertiser A,150.00,0.0\n"
        api_agency = "Agency Name (Mapped),Address Line 1,City, State  Zip Code\nAgency A,123 Main St,\"Secaucus, NJ  07094\"\n"
        api_adv = "Advertiser Name (Mapped),Address Line 1,City, State  Zip Code\nAdvertiser A,456 Elm St,\"Miami, FL  33181\"\n"

        def side_effect_get(url, **kwargs):
            resp = MagicMock()
            resp.status_code = 200
            url_lower = url.lower()

            if "sites/test.sharepoint.com" in url_lower:
                resp.json.return_value = {"id": "resolved_site_id"}
            elif "sites/resolved_site_id/drive" in url_lower:
                resp.json.return_value = {"id": "resolved_drive_id"}
            elif "root:/api:/children" in url_lower:
                # API files
                resp.json.return_value = {
                    "value": [
                        {"name": "Invoices.csv", "size": len(api_inv)},
                        {"name": "Agencies.csv", "size": len(api_agency)},
                        {"name": "Advertisers.csv", "size": len(api_adv)},
                    ]
                }
            elif "root:/rpa:/children" in url_lower:
                # RPA files
                resp.json.return_value = {
                    "value": [
                        {"name": "Invoices.xlsx", "size": len(rpa_inv)},
                        {"name": "Agencies.xlsx", "size": len(rpa_agency)},
                        {"name": "Advertisers.xlsx", "size": len(rpa_adv)},
                    ]
                }
            elif "invoices.xlsx:/content" in url_lower:
                resp.content = rpa_inv
            elif "agencies.xlsx:/content" in url_lower:
                resp.content = rpa_agency
            elif "advertisers.xlsx:/content" in url_lower:
                resp.content = rpa_adv
            elif "invoices.csv:/content" in url_lower:
                resp.content = api_inv.encode('utf-8')
            elif "agencies.csv:/content" in url_lower:
                resp.content = api_agency.encode('utf-8')
            elif "advertisers.csv:/content" in url_lower:
                resp.content = api_adv.encode('utf-8')
            else:
                resp.status_code = 404
            return resp

        mock_get.side_effect = side_effect_get

        # 3. Instantiate Wizard and Generate Master Workbook
        wizard = self.env['wideorbit.master.workbook'].create({
            'source_config_id': self.config.id,
        })
        action = wizard.action_generate_workbook()

        # 4. Assert download action and verify attachment
        self.assertIn('url', action)
        attachment_id = int(action['url'].split('/content/')[1].split('?')[0])
        attachment = self.env['ir.attachment'].browse(attachment_id)
        self.assertTrue(attachment.exists())
        self.assertEqual(attachment.name, 'WO_Master_Mapping_Workbook.xlsx')
        self.assertTrue(len(base64.b64decode(attachment.datas)) > 1000)
