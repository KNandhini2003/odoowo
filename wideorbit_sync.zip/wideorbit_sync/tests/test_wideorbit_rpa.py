# -*- coding: utf-8 -*-
import json
from odoo.tests.common import HttpCase

class TestWideOrbitRpaController(HttpCase):

    def setUp(self):
        super(TestWideOrbitRpaController, self).setUp()
        # Open a separate registry cursor to commit configuration outside the protected test cursor
        with self.registry.cursor() as cr:
            env = self.env(cr=cr)
            # Create a clean RPA configuration record
            env['wideorbit.rpa.config'].create({
                'name': 'Test RPA Config',
                'export_dir': '/tmp/test_rpa_out'
            })
            cr.commit()

    def tearDown(self):
        # Open a separate registry cursor to clean up our committed records
        with self.registry.cursor() as cr:
            env = self.env(cr=cr)
            env['wideorbit.rpa.config'].sudo().search([]).unlink()
            env['rpa.sync.log'].sudo().search([]).unlink()
            env['api.sync.log'].sudo().search([]).unlink()
            cr.commit()
        super(TestWideOrbitRpaController, self).tearDown()

    def test_log_rpa_run_success(self):
        """Verify successful POST calls record RPA execution statistics in Odoo."""
        url = '/wideorbit_sync/rpa/log_run'
        payload = {
            "jsonrpc": "2.0",
            "method": "call",
            "params": {
                "status": "success",
                "start_datetime": "2026-07-16 12:29:28",
                "end_datetime": "2026-07-16 12:31:46",
                "billing_month": "July",
                "excel_uploaded": True,
                "agency_excel_uploaded": True,
                "advertiser_excel_uploaded": True,
                "pdfs_uploaded": True,
                "pdfs_count": 1,
                "company_name": "910 Media",
                "exported_filename": "INV_WO_TEST.xlsx",
                "exported_records_count": 15,
                "details": "All processes executed successfully."
            }
        }
        
        response = self.url_open(
            url,
            data=json.dumps(payload),
            headers={'Content-Type': 'application/json'}
        )
        self.assertEqual(response.status_code, 200)
        
        res_data = response.json()
        self.assertIn('result', res_data)
        result = res_data['result']
        self.assertEqual(result.get('status'), 'success')
        self.assertTrue(result.get('log_id'))
        
        # Verify the database log entry matches the JSON post parameters
        log_rec = self.env['rpa.sync.log'].browse(result['log_id'])
        self.assertTrue(log_rec.exists())
        self.assertEqual(log_rec.status, 'success')
        self.assertEqual(log_rec.billing_month, 'July')
        self.assertEqual(log_rec.excel_uploaded, True)
        self.assertEqual(log_rec.pdfs_uploaded, True)
        self.assertEqual(log_rec.pdfs_count, 1)
        self.assertEqual(log_rec.exported_filename, 'INV_WO_TEST.xlsx')
        self.assertEqual(log_rec.exported_records_count, 15)
        self.assertEqual(log_rec.details, 'All processes executed successfully.')

    def test_log_api_run_success(self):
        """Verify successful POST calls record API Data Sync statistics in Odoo."""
        url = '/wideorbit_sync/api/log_run'
        payload = {
            "jsonrpc": "2.0",
            "method": "call",
            "params": {
                "status": "success",
                "invoice_uploaded": True,
                "agency_uploaded": True,
                "advertiser_uploaded": True,
                "excel_uploaded": True,
                "start_datetime": "2026-07-17 11:03:48",
                "end_datetime": "2026-07-17 11:04:06",
                "billing_month": "July 2026",
                "company_name": "910 Media",
                "details": "API upload log details."
            }
        }
        
        response = self.url_open(
            url,
            data=json.dumps(payload),
            headers={'Content-Type': 'application/json'}
        )
        self.assertEqual(response.status_code, 200)
        
        res_data = response.json()
        self.assertIn('result', res_data)
        result = res_data['result']
        self.assertEqual(result.get('status'), 'success')
        self.assertTrue(result.get('log_id'))
        
        # Verify the database log entry matches the JSON post parameters
        log_rec = self.env['api.sync.log'].browse(result['log_id'])
        self.assertTrue(log_rec.exists())
        self.assertEqual(log_rec.status, 'success')
        self.assertEqual(log_rec.billing_month, 'July 2026')
        self.assertEqual(log_rec.invoice_uploaded, True)
        self.assertEqual(log_rec.agency_uploaded, True)
        self.assertEqual(log_rec.advertiser_uploaded, True)
        self.assertEqual(log_rec.excel_uploaded, True)
        self.assertEqual(log_rec.details, 'API upload log details.')

    def test_log_api_run_legacy_fallback(self):
        """Verify legacy excel_uploaded maps to invoice_uploaded in api.sync.log when invoice_uploaded is missing."""
        url = '/wideorbit_sync/api/log_run'
        payload = {
            "jsonrpc": "2.0",
            "method": "call",
            "params": {
                "status": "success",
                "excel_uploaded": True,
                "start_datetime": "2026-07-17 11:03:48",
                "end_datetime": "2026-07-17 11:04:06",
                "billing_month": "July 2026",
                "company_name": "910 Media",
                "details": "Legacy format API run."
            }
        }
        
        response = self.url_open(
            url,
            data=json.dumps(payload),
            headers={'Content-Type': 'application/json'}
        )
        self.assertEqual(response.status_code, 200)
        
        res_data = response.json()
        self.assertIn('result', res_data)
        result = response.json()['result']
        
        log_rec = self.env['api.sync.log'].browse(result['log_id'])
        self.assertTrue(log_rec.exists())
        self.assertEqual(log_rec.excel_uploaded, True)
        self.assertEqual(log_rec.invoice_uploaded, True)
