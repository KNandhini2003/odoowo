# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class WideOrbitRpaConfig(models.Model):
    _name = 'wideorbit.rpa.config'
    _description = 'WideOrbit RPA Bot Configuration'

    name = fields.Char(string='Name', default='RPA Bot Configuration', required=True)
    export_dir = fields.Char(
        string='WideOrbit Export Directory',
        default=r'E:\9&10\WideOrdit Data\Output',
        required=True,
        help='Directory where the BotCity RPA bot saves the exported invoices.'
    )
    odoo_api_url = fields.Char(
        string='Odoo API Webhook URL',
        compute='_compute_odoo_api_url',
        help='Configure this URL in the bot\'s local .env file.'
    )
    odoo_base_url = fields.Char(
        string='Odoo Base URL',
        compute='_compute_odoo_base_url',
        help='Odoo Base URL to be configured in ODOO_URL of the local bot.'
    )

    @api.depends('name')
    def _compute_odoo_api_url(self):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        for record in self:
            record.odoo_api_url = f"{base_url.rstrip('/')}/wideorbit_sync/rpa/log_run"

    @api.depends('name')
    def _compute_odoo_base_url(self):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        for record in self:
            record.odoo_base_url = base_url.rstrip('/')

    def action_download_bot(self):
        """Action to download the pre-packaged BotCity RPA Bot zip bundle."""
        return {
            'type': 'ir.actions.act_url',
            'url': '/wideorbit_sync/download_bot',
            'target': 'new',
        }

    @api.model
    def action_open_config(self):
        config = self.search([], limit=1)
        if not config:
            config = self.create({})
        return {
            'type': 'ir.actions.act_window',
            'name': _('RPA Bot Configuration'),
            'res_model': 'wideorbit.rpa.config',
            'view_mode': 'form',
            'res_id': config.id,
            'target': 'current',
        }
