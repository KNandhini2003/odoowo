from odoo import models, fields

class AccountMove(models.Model):
    _inherit = 'account.move'

    wideorbit_invoice_id = fields.Char(
        string='WideOrbit Invoice ID',
        index=True,
        help='Unique identifier for the invoice in WideOrbit.'
    )
