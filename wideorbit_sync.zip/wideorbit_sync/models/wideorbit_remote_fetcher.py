# -*- coding: utf-8 -*-
import os
import logging
import urllib.parse
import requests
from abc import ABC, abstractmethod
from odoo.exceptions import UserError
from odoo import _

_logger = logging.getLogger(__name__)

class BaseRemoteFetcher(ABC):
    """
    Abstract interface for remote storage file fetchers.
    """
    @abstractmethod
    def connect(self) -> bool:
        """Establish connection and authenticate with remote service."""
        pass

    @abstractmethod
    def list_files(self, folder_path: str) -> list:
        """
        List files in the specified remote folder.
        Returns a list of dictionaries with keys: 'name', 'path', 'size'
        """
        pass

    @abstractmethod
    def download_file(self, file_path: str) -> bytes:
        """Download binary content of the specified remote file."""
        pass

    @abstractmethod
    def close(self):
        """Close connection handle."""
        pass


class SharePointFetcher(BaseRemoteFetcher):
    """
    SharePoint file fetcher using Microsoft Graph API with App Credentials.
    """
    def __init__(self, config):
        self.tenant_id = (config.sp_tenant_id or '').strip()
        self.client_id = (config.sp_client_id or '').strip()
        self.client_secret = (config.sp_client_secret or '').strip()
        self.site_domain = (config.sp_site_domain or 'powdrsolutions.sharepoint.com').strip()
        self.site_path = (config.sp_site_path or '/sites/documents_pkss').strip()
        
        self.access_token = None
        self.site_id = None
        self.drive_id = None

    def connect(self) -> bool:
        if not all([self.tenant_id, self.client_id, self.client_secret]):
            raise UserError(_("SharePoint API credentials (Tenant ID, Client ID, Client Secret) are not fully configured."))

        _logger.info("SharePoint Remote Fetcher: Requesting access token...")
        token_url = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": "https://graph.microsoft.com/.default"
        }

        try:
            res = requests.post(token_url, headers=headers, data=data, timeout=20)
            if res.status_code != 200:
                _logger.error("SharePoint Fetcher: Token request failed: HTTP %s - %s", res.status_code, res.text)
                return False
            self.access_token = res.json().get("access_token")
        except Exception as e:
            _logger.error("SharePoint Fetcher: Token request exception: %s", str(e))
            return False

        auth_headers = {"Authorization": f"Bearer {self.access_token}"}

        # Resolve Site ID
        _logger.info("SharePoint Remote Fetcher: Resolving Site ID for %s:%s...", self.site_domain, self.site_path)
        site_clean_path = self.site_path.strip("/")
        site_url = f"https://graph.microsoft.com/v1.0/sites/{self.site_domain}:/{site_clean_path}"
        try:
            site_res = requests.get(site_url, headers=auth_headers, timeout=20)
            if site_res.status_code != 200:
                _logger.error("SharePoint Fetcher: Site ID resolution failed: HTTP %s - %s", site_res.status_code, site_res.text)
                return False
            self.site_id = site_res.json().get("id")
        except Exception as e:
            _logger.error("SharePoint Fetcher: Site ID resolution exception: %s", str(e))
            return False

        # Resolve Drive ID
        _logger.info("SharePoint Remote Fetcher: Resolving Document Library (Drive ID)...")
        drive_url = f"https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive"
        try:
            drive_res = requests.get(drive_url, headers=auth_headers, timeout=20)
            if drive_res.status_code != 200:
                _logger.error("SharePoint Fetcher: Drive ID resolution failed: HTTP %s - %s", drive_res.status_code, drive_res.text)
                return False
            self.drive_id = drive_res.json().get("id")
            _logger.info("SharePoint Fetcher: Successfully connected and resolved Drive ID: %s", self.drive_id)
            return True
        except Exception as e:
            _logger.error("SharePoint Fetcher: Drive ID resolution exception: %s", str(e))
            return False

    def list_files(self, folder_path: str) -> list:
        if not self.access_token or not self.drive_id:
            raise UserError(_("SharePoint Fetcher: Not connected."))

        folder_clean = folder_path.replace("\\", "/").strip().strip("/")
        if folder_clean:
            encoded_folder = urllib.parse.quote(f"/{folder_clean}")
            children_url = f"https://graph.microsoft.com/v1.0/drives/{self.drive_id}/root:{encoded_folder}:/children"
        else:
            children_url = f"https://graph.microsoft.com/v1.0/drives/{self.drive_id}/root/children"

        headers = {"Authorization": f"Bearer {self.access_token}"}
        _logger.info("SharePoint Remote Fetcher: Listing files in remote directory '%s'...", folder_path)

        try:
            res = requests.get(children_url, headers=headers, timeout=20)
            if res.status_code != 200:
                _logger.error("SharePoint Fetcher: Failed to list files: HTTP %s - %s", res.status_code, res.text)
                return []

            items = res.json().get("value", [])
            files_list = []
            for item in items:
                # Only return files (skip folders)
                if "folder" not in item:
                    # Construct full item path relative to drive root
                    item_path = f"/{folder_clean}/{item['name']}".replace("//", "/")
                    files_list.append({
                        'name': item['name'],
                        'path': item_path,
                        'size': item.get('size', 0)
                    })
            return files_list
        except Exception as e:
            _logger.error("SharePoint Fetcher: List files exception: %s", str(e))
            return []

    def download_file(self, file_path: str) -> bytes:
        if not self.access_token or not self.drive_id:
            raise UserError(_("SharePoint Fetcher: Not connected."))

        file_clean = file_path.replace("\\", "/").strip().lstrip("/")
        encoded_file = urllib.parse.quote(f"/{file_clean}")
        content_url = f"https://graph.microsoft.com/v1.0/drives/{self.drive_id}/root:{encoded_file}:/content"

        headers = {"Authorization": f"Bearer {self.access_token}"}
        _logger.info("SharePoint Remote Fetcher: Downloading file '%s'...", file_clean)

        try:
            res = requests.get(content_url, headers=headers, timeout=60, allow_redirects=True)
            if res.status_code != 200:
                raise UserError(_("Failed to download file %s: HTTP %s - %s") % (file_path, res.status_code, res.text))
            return res.content
        except Exception as e:
            _logger.error("SharePoint Fetcher: Download file exception: %s", str(e))
            raise UserError(_("Error during remote download: %s") % str(e))

    def close(self):
        pass


class SFTPFetcher(BaseRemoteFetcher):
    """
    SFTP file fetcher implementation using paramiko.
    """
    def __init__(self, config):
        self.host = (config.sftp_host or '').strip()
        self.port = config.sftp_port or 22
        self.username = (config.sftp_username or '').strip()
        self.password = (config.sftp_password or '').strip()
        self.private_key = (config.sftp_private_key or '').strip()
        self.private_key_passphrase = (config.sftp_private_key_passphrase or '').strip()
        self.transport = None
        self.sftp = None

    def connect(self) -> bool:
        if not self.host or not self.username:
            raise UserError(_("SFTP is not fully configured (Host and Username are required)."))

        try:
            import paramiko
        except ImportError:
            raise UserError(_("Python library 'paramiko' is required for SFTP. Please run 'pip install paramiko' in your Odoo environment."))

        _logger.info("SFTP Fetcher: Connecting to %s:%s as '%s'...", self.host, self.port, self.username)
        try:
            import io
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            pkey = None
            if self.private_key:
                for key_class in (paramiko.RSAKey, paramiko.Ed25519Key, paramiko.ECDSAKey, paramiko.DSSKey):
                    try:
                        pkey = key_class.from_private_key(
                            io.StringIO(self.private_key),
                            password=self.private_key_passphrase or None
                        )
                        _logger.info("SFTP Fetcher: Successfully parsed private key using %s", key_class.__name__)
                        break
                    except Exception:
                        continue
                if not pkey:
                    raise UserError(_("Failed to parse SSH private key. Ensure the key format is correct and passphrase matches."))
            
            client.connect(
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password or None,
                pkey=pkey,
                timeout=20
            )
            self.sftp = client.open_sftp()
            self.transport = client.get_transport()
            _logger.info("SFTP Fetcher: Connected successfully.")
            return True
        except Exception as e:
            _logger.error("SFTP Fetcher: Connection failed: %s", str(e))
            self.close()
            return False

    def list_files(self, folder_path: str) -> list:
        if not self.sftp:
            raise UserError(_("SFTP Fetcher: Not connected."))

        folder_clean = folder_path.replace("\\", "/").rstrip('/')
        _logger.info("SFTP Fetcher: Listing files in remote directory '%s'...", folder_clean)
        try:
            files_list = []
            # listdir_attr returns SFTPAttributes objects
            for attr in self.sftp.listdir_attr(folder_clean):
                # Ensure it's not a directory
                import stat
                if not stat.S_ISDIR(attr.st_mode):
                    files_list.append({
                        'name': attr.filename,
                        'path': f"{folder_clean}/{attr.filename}",
                        'size': attr.st_size
                    })
            return files_list
        except Exception as e:
            _logger.error("SFTP Fetcher: List files exception: %s", str(e))
            return []

    def download_file(self, file_path: str) -> bytes:
        if not self.sftp:
            raise UserError(_("SFTP Fetcher: Not connected."))

        file_clean = file_path.replace("\\", "/")
        _logger.info("SFTP Fetcher: Downloading remote file '%s'...", file_clean)
        try:
            with self.sftp.open(file_clean, 'rb') as f:
                return f.read()
        except Exception as e:
            _logger.error("SFTP Fetcher: Download file exception: %s", str(e))
            raise UserError(_("Failed to download SFTP file %s: %s") % (file_path, str(e)))

    def close(self):
        if self.sftp:
            try:
                self.sftp.close()
            except Exception:
                pass
            self.sftp = None
        if self.transport:
            try:
                self.transport.close()
            except Exception:
                pass
            self.transport = None
        _logger.info("SFTP Fetcher: Connection closed.")


class RemoteFetcherFactory:
    """
    Factory to resolve and instantiate fetchers.
    """
    @staticmethod
    def get_fetcher(config) -> BaseRemoteFetcher:
        if config.data_source == 'sharepoint':
            return SharePointFetcher(config)
        elif config.data_source == 'sftp':
            return SFTPFetcher(config)
        else:
            raise UserError(_("Unsupported data source: %s") % config.data_source)
