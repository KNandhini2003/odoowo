from . import res_partner
from . import account_move
from . import wideorbit_sync_log
from . import wideorbit_sync
from . import wideorbit_rpa_config
from . import wideorbit_rpa_log
from . import api_sync_log
from . import wideorbit_source_config
from . import wideorbit_master_workbook

