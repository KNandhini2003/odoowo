# -*- coding: utf-8 -*-
import logging
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from .wideorbit_remote_fetcher import RemoteFetcherFactory

_logger = logging.getLogger(__name__)


class WideOrbitSourceConfig(models.Model):
    _name = 'wideorbit.source.config'
    _description = 'WideOrbit Remote Source Configuration'
    _rec_name = 'name'

    name = fields.Char(
        string='Configuration Name',
        default='WideOrbit Source Configuration',
        required=True
    )

    # Data Source Toggle
    data_source = fields.Selection([
        ('sharepoint', 'SharePoint (Microsoft Graph API)'),
        ('sftp', 'SFTP (SSH File Transfer Protocol)'),
    ], string='Data Source', default='sharepoint', required=True,
       help='Select the remote data source to fetch WideOrbit files from.')

    # SharePoint
    sp_tenant_id = fields.Char(
        string='Azure Tenant ID',
        help='Microsoft Azure Active Directory Tenant ID'
    )
    sp_client_id = fields.Char(
        string='Application (Client) ID',
        help='Azure App Registration Client ID'
    )
    sp_client_secret = fields.Char(
        string='Client Secret',
        help='Azure App Registration Client Secret Value'
    )
    sp_site_domain = fields.Char(
        string='SharePoint Site Domain',
        default='powdrsolutions.sharepoint.com',
        help='e.g. powdrsolutions.sharepoint.com'
    )
    sp_site_path = fields.Char(
        string='SharePoint Site Path',
        default='/sites/documents_pkss',
        help='e.g. /sites/documents_pkss'
    )
    sp_rpa_folder = fields.Char(
        string='RPA Folder Path',
        default='/7 - 910 Media/Wideorbit/RPA',
        help='Remote path (relative to drive root) to the RPA folder.'
    )
    sp_api_folder = fields.Char(
        string='API Folder Path',
        default='/7 - 910 Media/Wideorbit/API',
        help='Remote path (relative to drive root) to the API folder.'
    )
    sp_pdf_subfolder = fields.Char(
        string='PDF Subfolder Name',
        default='INVOICE_PDF',
        help='Name of the subfolder inside the RPA folder that contains invoice PDFs.'
    )

    # SFTP
    sftp_host = fields.Char(
        string='SFTP Host',
        help='SFTP server hostname or IP address'
    )
    sftp_port = fields.Integer(
        string='SFTP Port',
        default=22
    )
    sftp_username = fields.Char(string='SFTP Username')
    sftp_password = fields.Char(
        string='SFTP Password',
        help='SFTP login password'
    )
    sftp_private_key = fields.Text(
        string='SFTP Private Key',
        help='Paste your SSH private key content (RSA, Ed25519, etc.) here for key-based authentication.'
    )
    sftp_private_key_passphrase = fields.Char(
        string='Private Key Passphrase',
        help='Passphrase for the private key if it is encrypted.'
    )
    sftp_rpa_dir = fields.Char(
        string='SFTP RPA Directory',
        default='/wideorbit/rpa'
    )
    sftp_api_dir = fields.Char(
        string='SFTP API Directory',
        default='/wideorbit/api'
    )
    sftp_pdf_dir = fields.Char(
        string='SFTP PDF Directory',
        default='/wideorbit/rpa/invoice_pdf'
    )

    # Status / Metadata
    last_test_status = fields.Selection([
        ('success', 'Connected ✓'),
        ('failed', 'Failed ✗'),
        ('unknown', 'Not Tested'),
    ], string='Connection Status', default='unknown', readonly=True)
    last_test_message = fields.Char(
        string='Last Test Message',
        readonly=True
    )
    last_sync_date = fields.Datetime(
        string='Last Successful Sync',
        readonly=True
    )

    # Daily Cron Fields mapping
    daily_sync_active = fields.Boolean(
        string='Daily Sync Active',
        compute='_compute_daily_cron_fields',
        inverse='_inverse_daily_cron_fields',
        help='Toggle to enable or disable the daily automated sync.'
    )
    daily_sync_nextcall = fields.Datetime(
        string='Daily Next Execution Time',
        compute='_compute_daily_cron_fields',
        inverse='_inverse_daily_cron_fields',
        help='Next date and time the daily automated sync is scheduled to run.'
    )
    daily_sync_last_date = fields.Datetime(
        string='Daily Last Sync Date',
        readonly=True
    )

    # Weekly Cron Fields mapping
    weekly_sync_active = fields.Boolean(
        string='Weekly Sync Active',
        compute='_compute_weekly_cron_fields',
        inverse='_inverse_weekly_cron_fields',
        help='Toggle to enable or disable the weekly automated sync.'
    )
    weekly_sync_nextcall = fields.Datetime(
        string='Weekly Next Execution Time',
        compute='_compute_weekly_cron_fields',
        inverse='_inverse_weekly_cron_fields',
        help='Next date and time the weekly automated sync is scheduled to run.'
    )
    weekly_sync_last_date = fields.Datetime(
        string='Weekly Last Sync Date',
        readonly=True
    )

    # Legacy fields kept for compatibility
    cron_active = fields.Boolean(string='Legacy Scheduled Sync Active', default=False)
    cron_nextcall = fields.Datetime(string='Legacy Next Execution Time')
    cron_interval_number = fields.Integer(string='Legacy Sync Repeat Every', default=1)
    cron_interval_type = fields.Selection([('days', 'Days')], string='Legacy Interval Unit', default='days')

    def _get_daily_cron_record(self):
        try:
            return self.env.ref('wideorbit_sync.ir_cron_wideorbit_daily_sync')
        except Exception:
            return self.env['ir.cron'].search([
                ('model_id.model', '=', 'wideorbit.source.config'),
                ('code', 'ilike', 'action_run_daily_sync')
            ], limit=1)

    def _compute_daily_cron_fields(self):
        cron = self._get_daily_cron_record()
        for record in self:
            if cron:
                record.daily_sync_active = cron.active
                record.daily_sync_nextcall = cron.nextcall
            else:
                record.daily_sync_active = False
                record.daily_sync_nextcall = False

    def _inverse_daily_cron_fields(self):
        cron = self._get_daily_cron_record()
        if cron:
            for record in self:
                cron.write({
                    'active': record.daily_sync_active,
                    'nextcall': record.daily_sync_nextcall,
                })

    def _get_weekly_cron_record(self):
        try:
            return self.env.ref('wideorbit_sync.ir_cron_wideorbit_weekly_sync')
        except Exception:
            return self.env['ir.cron'].search([
                ('model_id.model', '=', 'wideorbit.source.config'),
                ('code', 'ilike', 'action_run_weekly_sync')
            ], limit=1)

    def _compute_weekly_cron_fields(self):
        cron = self._get_weekly_cron_record()
        for record in self:
            if cron:
                record.weekly_sync_active = cron.active
                record.weekly_sync_nextcall = cron.nextcall
            else:
                record.weekly_sync_active = False
                record.weekly_sync_nextcall = False

    def _inverse_weekly_cron_fields(self):
        cron = self._get_weekly_cron_record()
        if cron:
            for record in self:
                cron.write({
                    'active': record.weekly_sync_active,
                    'nextcall': record.weekly_sync_nextcall,
                })

    def action_run_daily_sync(self):
        self.ensure_one()
        _logger.info("Executing scheduled Daily Sync...")
        wizard = self.env['wideorbit.sync'].sudo().create({
            'source_config_id': self.id,
            'sync_mode': 'remote',
        })
        wizard.action_run_sync()
        self.sudo().write({'daily_sync_last_date': fields.Datetime.now()})

    def action_run_weekly_sync(self):
        self.ensure_one()
        _logger.info("Executing scheduled Weekly Sync...")
        wizard = self.env['wideorbit.sync'].sudo().create({
            'source_config_id': self.id,
            'sync_mode': 'remote',
        })
        wizard.action_run_sync()
        self.sudo().write({'weekly_sync_last_date': fields.Datetime.now()})

    def action_run_scheduled_sync(self):
        # Legacy fallback
        self.action_run_daily_sync()


    @api.model
    def get_config(self):
        config = self.search([], limit=1, order='id asc')
        if not config:
            config = self.create({'name': 'WideOrbit Source Configuration'})
        return config

    def _get_fetcher(self):
        self.ensure_one()
        return RemoteFetcherFactory.get_fetcher(self)

    def _get_data_folder_path(self):
        self.ensure_one()
        return (self.sftp_api_dir if self.data_source == 'sftp'
                else self.sp_api_folder or '/7 - 910 Media/Wideorbit/API')

    def _get_pdf_folder_path(self):
        self.ensure_one()
        if self.data_source == 'sftp':
            return self.sftp_pdf_dir or '/wideorbit/rpa/invoice_pdf'
        rpa_base = self.sp_rpa_folder or '/7 - 910 Media/Wideorbit/RPA'
        subfolder = self.sp_pdf_subfolder or 'INVOICE_PDF'
        return f"{rpa_base.rstrip('/')}/{subfolder}"

    def action_test_connection(self):
        self.ensure_one()
        source_label = dict(self._fields['data_source'].selection)[self.data_source]
        try:
            fetcher = self._get_fetcher()
            success = fetcher.connect()
            fetcher.close()
            if success:
                self.write({
                    'last_test_status': 'success',
                    'last_test_message': _('Connected to %s successfully.') % source_label,
                })
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Connection Successful'),
                        'message': _('Successfully connected to %s.') % source_label,
                        'type': 'success',
                        'sticky': False,
                    }
                }
            else:
                self.write({
                    'last_test_status': 'failed',
                    'last_test_message': _('Connection to %s failed. Check credentials.') % source_label,
                })
                raise UserError(_(
                    'Failed to connect to %s. Please verify your credentials and folder paths.'
                ) % source_label)
        except UserError:
            raise
        except Exception as e:
            msg = str(e)
            self.write({'last_test_status': 'failed', 'last_test_message': msg})
            raise UserError(_('Connection error: %s') % msg)

    def action_trigger_sync_now(self):
        self.ensure_one()
        wizard = self.env['wideorbit.sync'].create({
            'sync_mode': 'remote',
            'source_config_id': self.id,
        })
        result = wizard.action_run_sync()
        self.write({'last_sync_date': fields.Datetime.now()})
        return result

    @api.model
    def action_run_scheduled_sync(self):
        config = self.get_config()
        if not config:
            _logger.error('WideOrbit scheduled sync: No source configuration found.')
            return
        _logger.info('WideOrbit scheduled sync starting (config: %s, source: %s)',
                     config.name, config.data_source)
        try:
            wizard = self.env['wideorbit.sync'].create({
                'sync_mode': 'remote',
                'source_config_id': config.id,
            })
            wizard.action_run_sync()
            config.write({'last_sync_date': fields.Datetime.now()})
            _logger.info('WideOrbit scheduled sync completed successfully.')
        except Exception as e:
            _logger.error('WideOrbit scheduled sync failed: %s', str(e), exc_info=True)

    @api.model
    def action_open_config(self):
        config = self.get_config()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Remote Source Configuration'),
            'res_model': 'wideorbit.source.config',
            'view_mode': 'form',
            'res_id': config.id,
            'target': 'current',
        }
