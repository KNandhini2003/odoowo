from odoo import models, fields, api, _
from odoo.exceptions import UserError

class ResPartner(models.Model):
    _inherit = 'res.partner'

    wideorbit_agency_id = fields.Char(
        string='WideOrbit Agency ID',
        index=True,
        help='Unique identifier for the agency in WideOrbit.'
    )
    wideorbit_advertiser_id = fields.Char(
        string='WideOrbit Advertiser ID',
        index=True,
        help='Unique identifier for the advertiser in WideOrbit.'
    )

    @api.constrains('vat', 'parent_id')
    def _check_vat_commercial_fields(self):
        """Bypass commercial Tax ID constraint for WideOrbit partners,
        allowing synced agencies/advertisers to have distinct Tax IDs.
        """
        non_wo_partners = self.filtered(
            lambda p: not (
                p.wideorbit_agency_id or p.wideorbit_advertiser_id or
                (p.parent_id and (p.parent_id.wideorbit_agency_id or p.parent_id.wideorbit_advertiser_id)) or
                (p.commercial_partner_id and (p.commercial_partner_id.wideorbit_agency_id or p.commercial_partner_id.wideorbit_advertiser_id))
            )
        )
        if non_wo_partners:
            try:
                super(ResPartner, non_wo_partners)._check_vat_commercial_fields()
            except AttributeError:
                pass
