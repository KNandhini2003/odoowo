import io
import os
import glob
import re
import datetime
import base64
import logging
import zipfile
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

try:
    from openpyxl import load_workbook
except ImportError:
    _logger.warning("openpyxl is not installed. WideOrbit Sync will not be functional.")


class WideOrbitSync(models.TransientModel):
    _name = 'wideorbit.sync'
    _description = 'WideOrbit Sync Wizard'

    def _default_source_config(self):
        try:
            return self.env['wideorbit.source.config'].sudo().get_config()
        except Exception:
            return False

    source_config_id = fields.Many2one(
        'wideorbit.source.config',
        string='Source Configuration',
        default=_default_source_config,
        required=True
    )

    # Related fields to schedule config
    daily_sync_active = fields.Boolean(related='source_config_id.daily_sync_active', string='Daily Sync Active', readonly=False)
    daily_sync_nextcall = fields.Datetime(related='source_config_id.daily_sync_nextcall', string='Daily Next Execution Time', readonly=False)
    daily_sync_last_date = fields.Datetime(related='source_config_id.daily_sync_last_date', string='Daily Last Sync Date', readonly=True)

    weekly_sync_active = fields.Boolean(related='source_config_id.weekly_sync_active', string='Weekly Sync Active', readonly=False)
    weekly_sync_nextcall = fields.Datetime(related='source_config_id.weekly_sync_nextcall', string='Weekly Next Execution Time', readonly=False)
    weekly_sync_last_date = fields.Datetime(related='source_config_id.weekly_sync_last_date', string='Weekly Last Sync Date', readonly=True)

    def _parse_city_state_zip(self, value):
        """Parse City, State, Zip from a single string.
        Example: Secaucus, NJ 07094 or Traverse City, MI 49686.
        """
        if not value or not isinstance(value, str):
            return None, None, None
        
        parts = value.split(',', 1)
        if len(parts) == 2:
            city = parts[0].strip()
            rest = parts[1].strip()
            rest_parts = [p.strip() for p in rest.split(' ') if p.strip()]
            if len(rest_parts) >= 2:
                state_code = rest_parts[0]
                zip_code = " ".join(rest_parts[1:])
                return city, state_code, zip_code
            elif len(rest_parts) == 1:
                val = rest_parts[0]
                if val.isalpha() and len(val) == 2:
                    return city, val, None
                else:
                    return city, None, val
        else:
            tokens = [t.strip() for t in value.split(' ') if t.strip()]
            if len(tokens) >= 3:
                city = " ".join(tokens[:-2])
                state_code = tokens[-2]
                zip_code = tokens[-1]
                return city, state_code, zip_code
        return None, None, None

    def _parse_date(self, date_val):
        """Parse dates in various formats to Date object."""
        if not date_val:
            return False
        if isinstance(date_val, (fields.Date, fields.Datetime)):
            return date_val
        if isinstance(date_val, (datetime.date, datetime.datetime)):
            return date_val
        
        date_str = str(date_val).strip()
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%d', '%m/%d/%y', '%m/%d/%Y'):
            try:
                return datetime.datetime.strptime(date_str, fmt).date()
            except ValueError:
                continue
        return False

    def _clean_str(self, val):
        if val is None:
            return ''
        val = str(val).strip()
        if val.lower() == 'none' or val == '':
            return ''
        return val

    def _get_row_val(self, row, keys_to_try):
        """Lookup key in row dictionary following the priority order of keys_to_try,
        automatically matching variants with or without [RPA], [API], RPA_, or API_ prefixes.
        """
        def normalize_key(k):
            s = str(k).lower().strip()
            # Remove brackets [rpa] or [api]
            s = re.sub(r'^\[(?:rpa|api)\]\s*', '', s)
            # Remove prefix rpa_ or api_
            if s.startswith('rpa_'):
                s = s[4:]
            elif s.startswith('api_'):
                s = s[4:]
            # Replace spaces and symbols for uniform matching
            return s.replace(' ', '_').replace('-', '_').replace('#', '').strip('_')

        row_clean = {}
        for key, val in row.items():
            if val is not None and str(val).strip() != '':
                norm_k = normalize_key(key)
                row_clean[norm_k] = val

        for target_key in keys_to_try:
            norm_target = normalize_key(target_key)
            if norm_target in row_clean:
                return row_clean[norm_target]

        return None

    def _get_active_sheet(self, wb, sheet_name=None):
        if sheet_name:
            if sheet_name not in wb.sheetnames:
                for name in wb.sheetnames:
                    if name.lower() == sheet_name.lower():
                        return wb[name]
                return wb.active
            else:
                return wb[sheet_name]
        return wb.active

    def _read_file_data(self, file_path=None, binary_data=None, filename=None, sheet_name=None):
        """Read sheet rows from CSV, XLS, or XLSX formats, with header scanner and auto-fallback."""
        def safe_decode_base64(data):
            if not data:
                return b''
            if isinstance(data, str):
                try:
                    return base64.b64decode(data.strip())
                except Exception:
                    return data.encode('utf-8')
            if isinstance(data, bytes):
                if data.startswith(b'PK\x03\x04') or data.startswith(b'\xd0\xcf\x11\xe0'):
                    return data
                # Only trust a base64 decode if the input is STRICTLY valid base64
                # (validate=True rejects any character outside the base64 alphabet,
                # e.g. spaces, commas, '#', newlines found in real CSV/text content).
                # Previously this only accepted the decode when the *result* looked
                # like an xlsx/xls binary signature, which silently left genuine
                # base64-encoded CSV/text content un-decoded (garbled data).
                try:
                    # Strip any whitespace/newlines before validation
                    cleaned_data = re.sub(rb'\s+', b'', data)
                    decoded = base64.b64decode(cleaned_data, validate=True)
                    return decoded
                except Exception:
                    pass
                return data
            return data

        fmt = 'xlsx'
        if filename:
            ext = filename.split('.')[-1].lower()
            if ext in ('csv', 'xls', 'xlsx'):
                fmt = ext
        elif file_path:
            ext = file_path.split('.')[-1].lower()
            if ext in ('csv', 'xls', 'xlsx'):
                fmt = ext

        formats_to_try = [fmt]

        last_error = None
        for current_fmt in formats_to_try:
            try:
                # A. CSV Format
                if current_fmt == 'csv':
                    if binary_data:
                        decoded = safe_decode_base64(binary_data)
                        try:
                            text = decoded.decode('utf-8-sig')
                        except UnicodeDecodeError:
                            text = decoded.decode('latin-1')
                    else:
                        if not os.path.exists(file_path):
                            raise UserError(_("File not found: %s") % file_path)
                        with open(file_path, mode='r', encoding='utf-8-sig') as f:
                            text = f.read()
                    
                    import csv
                    reader = csv.reader(text.splitlines())
                    rows = list(reader)
                    if not rows:
                        return []

                    # Scan first 10 rows to locate the header row
                    header_idx = 0
                    for idx, r in enumerate(rows[:10]):
                        row_strs = [str(cell).strip().lower() for cell in r if cell is not None and str(cell).strip()]
                        if len(row_strs) >= 3 and any("invoice" in s or "billing" in s or "net" in s or "agency" in s or "advertiser" in s or "amount" in s for s in row_strs):
                            header_idx = idx
                            break

                    headers = [str(cell).strip() for cell in rows[header_idx]]
                    data = []
                    for r in rows[header_idx + 1:]:
                        if any(cell != '' and cell is not None for cell in r):
                            row_dict = {}
                            for idx, cell in enumerate(r):
                                if idx < len(headers):
                                    row_dict[headers[idx]] = cell
                            data.append(row_dict)
                    return data

                # B. XLS Format
                elif current_fmt == 'xls':
                    import xlrd
                    if binary_data:
                        decoded = safe_decode_base64(binary_data)
                        book = xlrd.open_workbook(file_contents=decoded)
                    else:
                        if not os.path.exists(file_path):
                            raise UserError(_("File not found: %s") % file_path)
                        book = xlrd.open_workbook(file_path)

                    if sheet_name:
                        sheet = None
                        for name in book.sheet_names():
                            if name.lower() == sheet_name.lower():
                                sheet = book.sheet_by_name(name)
                                break
                        if not sheet:
                            sheet = book.sheet_by_index(0)
                    else:
                        sheet = book.sheet_by_index(0)

                    if sheet.nrows == 0:
                        return []

                    # Scan first 10 rows to locate the header row
                    header_idx = 0
                    for idx in range(min(10, sheet.nrows)):
                        row_strs = [str(sheet.cell_value(idx, col)).strip().lower() for col in range(sheet.ncols) if sheet.cell_value(idx, col) is not None and str(sheet.cell_value(idx, col)).strip()]
                        if len(row_strs) >= 3 and any("invoice" in s or "billing" in s or "net" in s or "agency" in s or "advertiser" in s or "amount" in s for s in row_strs):
                            header_idx = idx
                            break

                    headers = [str(sheet.cell_value(header_idx, col)).strip() for col in range(sheet.ncols)]
                    data = []
                    for row_idx in range(header_idx + 1, sheet.nrows):
                        row_vals = [sheet.cell_value(row_idx, col) for col in range(sheet.ncols)]
                        if any(val != '' and val is not None for val in row_vals):
                            row_dict = {}
                            for col_idx, val in enumerate(row_vals):
                                if col_idx < len(headers):
                                    # Clean float formatting from old Excel cell readings
                                    if isinstance(val, float) and val.is_integer():
                                        val = int(val)
                                    row_dict[headers[col_idx]] = val
                            data.append(row_dict)
                    return data

                # C. XLSX Format
                else:
                    import zipfile
                    if binary_data:
                        raw_bytes = safe_decode_base64(binary_data)
                    else:
                        if not os.path.exists(file_path):
                            raise UserError(_("File not found: %s") % file_path)
                        with open(file_path, 'rb') as f:
                            raw_bytes = f.read()

                    # Sanitize Zip structure in memory to fix openpyxl's missing sharedStrings bug
                    try:
                        in_memory_zip = io.BytesIO(raw_bytes)
                        with zipfile.ZipFile(in_memory_zip, 'r') as zin:
                            names = zin.namelist()
                            has_lower = 'xl/sharedStrings.xml' in names
                            has_upper = any(n.lower() == 'xl/sharedstrings.xml' for n in names)
                            
                            if not has_lower:
                                out_memory_zip = io.BytesIO()
                                with zipfile.ZipFile(out_memory_zip, 'w', zipfile.ZIP_DEFLATED) as zout:
                                    for item in zin.infolist():
                                        if item.filename.lower() == 'xl/sharedstrings.xml':
                                            continue
                                        zout.writestr(item.filename, zin.read(item.filename))
                                    
                                    if has_upper:
                                        upper_name = next(n for n in names if n.lower() == 'xl/sharedstrings.xml')
                                        zout.writestr('xl/sharedStrings.xml', zin.read(upper_name))
                                    else:
                                        dummy_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="0" uniqueCount="0"></sst>'
                                        zout.writestr('xl/sharedStrings.xml', dummy_xml.encode('utf-8'))
                                
                                raw_bytes = out_memory_zip.getvalue()
                    except Exception as zip_err:
                        _logger.warning("Failed to sanitize Excel zip structure: %s", zip_err)

                    file_io = io.BytesIO(raw_bytes)
                    try:
                        wb = load_workbook(file_io, read_only=True, data_only=True)
                        ws = self._get_active_sheet(wb, sheet_name)
                        rows = list(ws.iter_rows(values_only=True))
                    except KeyError:
                        file_io.seek(0)
                        wb = load_workbook(file_io, data_only=True)
                        ws = self._get_active_sheet(wb, sheet_name)
                        rows = list(ws.iter_rows(values_only=True))
                    if not rows:
                        return []

                    # Scan first 10 rows to locate the header row
                    header_idx = 0
                    for idx, r in enumerate(rows[:10]):
                        row_strs = [str(cell).strip().lower() for cell in r if cell is not None and str(cell).strip()]
                        if len(row_strs) >= 3 and any("invoice" in s or "billing" in s or "net" in s or "agency" in s or "advertiser" in s or "amount" in s for s in row_strs):
                            header_idx = idx
                            break

                    headers = [str(cell).strip() if cell is not None else f"Col_{i}" for i, cell in enumerate(rows[header_idx])]
                    data = []
                    for r in rows[header_idx + 1:]:
                        if any(cell is not None for cell in r):
                            row_dict = {}
                            for idx, cell in enumerate(r):
                                if idx < len(headers):
                                    row_dict[headers[idx]] = cell
                            data.append(row_dict)
                    return data

            except Exception as e:
                last_error = e
                # Continue loop to try fallback format
                continue

        # If all formats failed to parse, raise a user-friendly error
        file_desc = filename or file_path or "uploaded file"
        raise UserError(_(
            "Failed to parse file (%s). Please verify that the file format is valid (CSV, XLS, or XLSX).\nDetails: %s"
        ) % (file_desc, str(last_error)))

    def _resolve_partner(self, name, wo_id, is_agency, sheet_data_dict, log_lines, company=False):
        """Find or create a partner in Odoo based on the matching hierarchy."""
        excel_row = sheet_data_dict.get(name.lower()) if name else None

        email = ''
        phone = ''
        street = ''
        street2 = ''
        city = ''
        state_code = ''
        zip_code = ''
        country_name = ''
        website = ''
        vat = ''
        category_id_vals = False
        updated_date = None

        if excel_row:
            email = self._clean_str(self._get_row_val(excel_row, ['Statement Email', 'Email', 'Agency Email', 'Advertiser Email']))
            phone = self._clean_str(self._get_row_val(excel_row, ['Phone', 'Agency Phone', 'Advertiser Phone']))
            street = self._clean_str(self._get_row_val(excel_row, ['Address Line 1', 'Address 1', 'Street']))
            street2 = self._clean_str(self._get_row_val(excel_row, ['Address Line 2', 'Address 2', 'Street2'])) or ''
            addr3 = self._clean_str(self._get_row_val(excel_row, ['Address Line 3', 'Address 3']))
            if addr3:
                street2 = (street2 + ' ' + addr3).strip()
            
            city_state_zip_raw = self._get_row_val(excel_row, ['City, State  Zip Code', 'City, State Zip', 'CityStateZip', 'City, State Zip Code'])
            city, state_code, zip_code = self._parse_city_state_zip(city_state_zip_raw)
            if not city:
                city = self._clean_str(self._get_row_val(excel_row, ['City']))
            if not zip_code:
                zip_code = self._clean_str(self._get_row_val(excel_row, ['Zip Code', 'Zip', 'Postal Code']))
            if not state_code:
                state_code = self._clean_str(self._get_row_val(excel_row, ['State', 'Province']))

            country_name = self._clean_str(self._get_row_val(excel_row, ['Country']))
            website = self._clean_str(self._get_row_val(excel_row, ['Website', 'Web', 'URL']))

            if not is_agency:
                vat = self._clean_str(self._get_row_val(excel_row, ['Tax 1/Tax 2', 'Tax 1', 'Tax 2', 'Tax ID', 'VAT']))
                tag_name = self._clean_str(self._get_row_val(excel_row, ['2/Rev Code 4', 'Rev Code 4', 'Tags', 'Category']))
                if tag_name:
                    category = self.env['res.partner.category'].search([('name', '=ilike', tag_name)], limit=1)
                    if not category:
                        category = self.env['res.partner.category'].create({'name': tag_name})
                    category_id_vals = [(6, 0, [category.id])]
            
            updated_date_raw = self._get_row_val(excel_row, [
                'Agency Updated Date', 'Advertiser Updated Date', 'Updated Date', 
                'Last Modified', 'Modified Date', 'Update Date', 'UPDATED_DATE',
                'Agency Updated', 'Advertiser Updated'
            ])
            if updated_date_raw:
                updated_date = self._parse_date(updated_date_raw)

        # Find country & state in Odoo
        country_id = False
        if country_name:
            country = self.env['res.country'].search([('name', '=ilike', country_name)], limit=1)
            if not country:
                country = self.env['res.country'].search([('code', '=ilike', country_name)], limit=1)
            if country:
                country_id = country.id
        if not country_id:
            country = self.env['res.country'].search([('code', '=', 'US')], limit=1)
            if country:
                country_id = country.id

        state_id = False
        if state_code and country_id:
            state = self.env['res.country.state'].search([
                ('code', '=ilike', state_code),
                ('country_id', '=', country_id)
            ], limit=1)
            if state:
                state_id = state.id

        if not company:
            company = self.env.company

        account_model = self.env['account.account']
        company_field = 'company_ids' if 'company_ids' in account_model._fields else 'company_id'
        
        receivable_account = account_model.search([
            ('account_type', 'in', ('asset_receivable', 'receivable')),
            (company_field, '=', company.id)
        ], limit=1)
        
        payable_account = account_model.search([
            ('account_type', 'in', ('liability_payable', 'payable')),
            (company_field, '=', company.id)
        ], limit=1)

        partner_vals = {
            'name': name,
            'is_company': True,
            'company_type': 'company',
            'type': 'contact',
            'street': street or False,
            'street2': street2 or False,
            'city': city or False,
            'state_id': state_id or False,
            'zip': zip_code or False,
            'country_id': country_id or False,
            'email': email or False,
            'phone': phone or False,
            'website': website or False,
        }

        if vat:
            partner_vals['vat'] = vat
        if category_id_vals:
            partner_vals['category_id'] = category_id_vals

        if receivable_account:
            partner_vals['property_account_receivable_id'] = receivable_account.id
        if payable_account:
            partner_vals['property_account_payable_id'] = payable_account.id

        if is_agency:
            partner_vals['wideorbit_agency_id'] = wo_id or False
        else:
            partner_vals['wideorbit_advertiser_id'] = wo_id or False

        partner = None

        # Priority 1: Lookup by WideOrbit ID
        domain = []
        if is_agency and wo_id:
            domain = [('wideorbit_agency_id', '=', wo_id)]
        elif not is_agency and wo_id:
            domain = [('wideorbit_advertiser_id', '=', wo_id)]

        if domain:
            partner = self.env['res.partner'].search(domain, limit=1)

        # Priority 2: Lookup by Email
        if not partner and email:
            partner = self.env['res.partner'].search([('email', '=', email), ('is_company', '=', True)], limit=1)

        # Priority 3: Lookup by Phone
        if not partner and phone:
            partner = self.env['res.partner'].search([('phone', '=', phone), ('is_company', '=', True)], limit=1)

        # Priority 4: Lookup by Company Name
        if not partner and name:
            partner = self.env['res.partner'].search([('name', '=ilike', name), ('is_company', '=', True)], limit=1)

        status = 'skipped'
        if partner:
            # Check Updated Date condition: Only update if Updated Date is today
            today_date = fields.Date.context_today(self)
            should_update = True
            if updated_date and updated_date != today_date:
                should_update = False

            if should_update:
                update_vals = {}
                for key, val in partner_vals.items():
                    if val and partner[key] != val:
                        update_vals[key] = val
                if update_vals:
                    partner.write(update_vals)
                    log_lines.append(_("Updated existing partner %s (ID: %s)") % (partner.name, partner.id))
                    status = 'updated'
                else:
                    status = 'skipped'
            else:
                log_lines.append(_("Partner %s (ID: %s) exists, but Updated Date (%s) is not today. Skipping update.") % (partner.name, partner.id, updated_date))
                status = 'skipped'
        else:
            # Priority 5: Create new Company Contact
            partner = self.env['res.partner'].create(partner_vals)
            log_lines.append(_("Created new partner %s (ID: %s)") % (partner.name, partner.id))
            status = 'created'

        return partner, status

    def _attach_pdfs_to_invoices(self, fetcher, invoice_ids, log_lines):
        """Find and attach corresponding PDFs from remote storage to synchronized invoices."""
        if not invoice_ids or not fetcher:
            return
        
        config = self.source_config_id or self.env['wideorbit.source.config'].get_config()
        pdf_folder = config._get_pdf_folder_path()
        log_lines.append("Listing remote PDF attachments in: %s" % pdf_folder)
        
        try:
            pdf_files = fetcher.list_files(pdf_folder)
        except Exception as ex:
            log_lines.append("Error listing PDF files: %s" % str(ex))
            return

        if not pdf_files:
            log_lines.append("No files found in remote PDF folder.")
            return

        invoices = self.env['account.move'].browse(invoice_ids)
        invoice_refs = []
        for inv in invoices:
            refs = []
            if inv.ref:
                refs.append(inv.ref.strip().lower())
            if inv.wideorbit_invoice_id:
                refs.append(inv.wideorbit_invoice_id.strip().lower())
            if inv.name and inv.name != '/':
                refs.append(inv.name.strip().lower())
            
            for r in refs:
                if r:
                    invoice_refs.append((r, inv))

        attached_count = 0
        for pdf in pdf_files:
            pdf_name = pdf['name']
            pdf_name_lower = pdf_name.lower()
            if not pdf_name_lower.endswith('.pdf'):
                continue
            
            pdf_stem = os.path.splitext(pdf_name_lower)[0].strip()
            
            # Find all matching invoices whose Invoice # is a prefix of the PDF filename
            for ref_lower, move in invoice_refs:
                if pdf_stem.startswith(ref_lower) or pdf_name_lower.startswith(ref_lower):
                    # Check if this PDF is already attached to this invoice
                    existing = self.env['ir.attachment'].search([
                        ('res_model', '=', 'account.move'),
                        ('res_id', '=', move.id),
                        ('name', '=', pdf_name)
                    ], limit=1)
                    
                    if not existing:
                        try:
                            log_lines.append("Downloading and attaching PDF: %s -> Invoice %s" % (pdf_name, move.ref or move.id))
                            pdf_data = fetcher.download_file(pdf['path'])
                            self.env['ir.attachment'].create({
                                'name': pdf_name,
                                'type': 'binary',
                                'datas': base64.b64encode(pdf_data),
                                'res_model': 'account.move',
                                'res_id': move.id,
                                'mimetype': 'application/pdf',
                            })
                            move.message_post(body=_("WideOrbit PDF Attachment synced from remote storage: %s") % pdf_name)
                            attached_count += 1
                        except Exception as ex:
                            log_lines.append("Error downloading/attaching PDF %s: %s" % (pdf_name, str(ex)))
                    else:
                        log_lines.append("PDF %s already attached to Invoice %s. Skipping." % (pdf_name, move.ref or move.id))

        log_lines.append("PDF synchronization complete. Attached %d new files." % attached_count)

    def action_run_sync(self):
        self.ensure_one()
        log_lines = []
        log_lines.append("Starting WideOrbit Synchronization Job.")
        log_lines.append("Timestamp: %s" % datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        invoices_processed = 0
        status = 'success'
        fetcher = None

        # Track uniquely synced IDs and statuses
        agency_statuses = {}
        advertiser_statuses = {}
        invoice_statuses = {}

        try:
            # Resolve Master Workbook from Remote Source Configuration
            wb = None
            config = self.source_config_id or self.env['wideorbit.source.config'].get_config()
            if not config:
                raise UserError(_("No remote source configuration found."))
            
            # Connect and list remote files to fetch PDF attachments later
            fetcher = config._get_fetcher()
            log_lines.append("Connecting to remote storage...")
            if not fetcher.connect():
                raise UserError(_("Failed to connect to remote source."))

            log_lines.append("Downloading and generating consolidated Master Workbook from remote storage...")
            master_wb_wizard = self.env['wideorbit.master.workbook'].create({
                'source_config_id': config.id
            })
            wb = master_wb_wizard._generate_workbook_object()
            log_lines.append("Master Workbook successfully generated and loaded.")

            if not wb:
                raise UserError(_("Failed to load Master Workbook."))

            # Ensure all required worksheets exist
            if 'Invoice' not in wb.sheetnames or 'Agency' not in wb.sheetnames or 'Advertiser' not in wb.sheetnames:
                raise UserError(_("The Master Workbook does not contain the required sheets: 'Invoice', 'Agency', and 'Advertiser'."))

            invoice_sheet = wb['Invoice']
            agency_sheet = wb['Agency']
            advertiser_sheet = wb['Advertiser']

            # Helper to convert sheet into list of dicts
            def _parse_openpyxl_sheet(ws):
                rows = list(ws.iter_rows(values_only=True))
                if not rows:
                    return []
                headers = [str(h).strip() if h is not None else '' for h in rows[0]]
                data = []
                for row in rows[1:]:
                    if not any(val is not None for val in row):
                        continue
                    row_dict = {}
                    for col_idx, val in enumerate(row):
                        if col_idx < len(headers):
                            h = headers[col_idx]
                            if h:
                                row_dict[h] = val
                    data.append(row_dict)
                return data

            log_lines.append("Parsing worksheets...")
            invoice_rows = _parse_openpyxl_sheet(invoice_sheet)
            agency_rows = _parse_openpyxl_sheet(agency_sheet)
            advertiser_rows = _parse_openpyxl_sheet(advertiser_sheet)

            agencies_data = {}
            for r in agency_rows:
                name = self._get_row_val(r, ['Agency Name', 'Agency', 'Agency Name (Mapped)'])
                if name:
                    agencies_data[str(name).strip().lower()] = r

            advertisers_data = {}
            for r in advertiser_rows:
                name = self._get_row_val(r, ['Advertiser Name', 'Advertiser', 'Advertiser Name (Mapped)'])
                if name:
                    advertisers_data[str(name).strip().lower()] = r

            log_lines.append("Loaded %d agencies, %d advertisers, %d invoice rows from Master Workbook." % (
                len(agency_rows), len(advertiser_rows), len(invoice_rows)
            ))

            # A. Prefetch and cache standard lookups in bulk (to reduce DB hits to 0 inside the loop)
            log_lines.append("Caching database settings...")
            all_companies = self.env['res.company'].search([])
            company_cache = {c.name.lower(): c for c in all_companies}

            all_journals = self.env['account.journal'].search([('type', '=', 'sale')])
            journal_cache = {j.company_id.id: j for j in all_journals}

            account_model = self.env['account.account']
            company_field = 'company_ids' if 'company_ids' in account_model._fields else 'company_id'
            
            all_accounts = account_model.search([
                '|',
                ('code', '=', '1550'),
                ('account_type', '=', 'income')
            ])
            account_cache = {}
            for acc in all_accounts:
                c_ids = acc.company_ids.ids if company_field == 'company_ids' else [acc.company_id.id]
                for cid in c_ids:
                    if cid not in account_cache:
                        account_cache[cid] = {}
                    if acc.code == '1550':
                        account_cache[cid]['1550'] = acc
                    elif acc.account_type == 'income' and 'income' not in account_cache[cid]:
                        account_cache[cid]['income'] = acc

            resolved_partners_cache = {}
            moves_to_post = self.env['account.move']

            for row in invoice_rows:
                # 1. Extract Invoice Number and Unique ID
                invoice_number = self._clean_str(self._get_row_val(row, [
                    'Invoice Number', 'RPA_Invoice #', 'Invoice #', 'InvoiceNo', 'INVOICE_NUMBER',
                    'INVOICE_ID (Mapped)', 'API_INVOICE_ID', 'INV_NO', 'INV#', 'InvoiceID', 'Invoice ID', 'Invoice'
                ]))
                if not invoice_number:
                    continue

                invoices_processed += 1
                invoice_id = self._clean_str(self._get_row_val(row, [
                    'API_API_INVOICE_ID', 'API_INVOICE_ID', 'INVOICE_ID (Mapped)', 'INVOICE_ID', 'Invoice ID', 'RPA_Invoice #'
                ])) or invoice_number

                # Resolve billing company from cache
                billing_group = self._clean_str(self._get_row_val(row, ['Billing Group', 'BillingGroup', 'Billing Company', 'Company']))
                company = company_cache.get(billing_group.lower()) if billing_group else False
                if not company:
                    company = self.env.company

                # 2. Extract Agency from Invoice row (RPA_Agency)
                agency_name = self._clean_str(self._get_row_val(row, [
                    'RPA_Agency', 'RPA Agency', 'Agency Name (Mapped)', 'Agency Name', 'Agency_Name', 'AGENCY_NAME', 'AGENCY', 'Agency',
                    'Billing Agency', 'Billing Agency Name', 'BILLING_AGENCY', 'BILLING_AGENCY_NAME'
                ]))
                
                # Fetch Agency ID from invoice row first, then fallback to metadata
                agency_id = self._clean_str(self._get_row_val(row, [
                    'API_API_AGENCY_ID', 'API_AGENCY_ID', 'Agency ID (Mapped)', 'Agency ID', 'Agency_ID', 'AgencyID', 'AGENCY_ID', 'AGENCY_CODE', 'Agency Code'
                ]))
                agency_dict_row = agencies_data.get(agency_name.lower()) if agency_name else None
                if agency_dict_row and not agency_id:
                    agency_id = self._clean_str(self._get_row_val(agency_dict_row, [
                        'API_API_AGENCY_ID', 'API_AGENCY_ID', 'Agency ID (Mapped)', 'Agency ID', 'Agency_ID', 'AgencyID', 'AGENCY_ID'
                    ]))

                # 3. Extract Advertiser from Invoice row (RPA_Advertiser)
                advertiser_name = self._clean_str(self._get_row_val(row, [
                    'RPA_Advertiser', 'RPA Advertiser', 'Advertiser Name (Mapped)', 'Advertiser Name', 'Advertiser_Name', 'ADVERTISER_NAME', 'ADVERTISER', 'Advertiser',
                    'Customer Name', 'Customer', 'Bill To', 'Bill To Name', 'Account Name', 'Account',
                    'Billing Advertiser', 'Billing Advertiser Name', 'BILLING_ADVERTISER', 'BILLING_ADVERTISER_NAME'
                ]))
                
                # Fetch Advertiser ID from invoice row first, then fallback to metadata
                advertiser_id = self._clean_str(self._get_row_val(row, [
                    'API_API_ADVERTISER_ID', 'API_ADVERTISER_ID', 'Advertiser ID (Mapped)', 'Advertiser ID', 'Advertiser_ID', 'AdvertiserID', 'ADVERTISER_ID',
                    'Customer ID', 'CustomerID', 'CUSTOMER_ID', 'ADVERTISER_CODE', 'Advertiser Code'
                ]))
                advertiser_dict_row = advertisers_data.get(advertiser_name.lower()) if advertiser_name else None
                if advertiser_dict_row and not advertiser_id:
                    advertiser_id = self._clean_str(self._get_row_val(advertiser_dict_row, [
                        'API_API_ADVERTISER_ID', 'API_ADVERTISER_ID', 'Advertiser ID (Mapped)', 'Advertiser ID', 'Advertiser_ID', 'AdvertiserID', 'ADVERTISER_ID'
                    ]))

                if not advertiser_name and agency_name:
                    advertiser_name = agency_name

                # 4. Synchronize Agency for this Invoice
                agency_partner = None
                if agency_name:
                    agency_key = ('agency', agency_name.lower(), agency_id or '')
                    if agency_key in resolved_partners_cache:
                        agency_partner, agency_status = resolved_partners_cache[agency_key]
                    else:
                        agency_partner, agency_status = self._resolve_partner(
                            agency_name, agency_id, is_agency=True,
                            sheet_data_dict=agencies_data, log_lines=log_lines,
                            company=company
                        )
                        resolved_partners_cache[agency_key] = (agency_partner, agency_status)
                    agency_statuses[agency_partner.id] = agency_status

                # 5. Synchronize Advertiser for this Invoice
                advertiser_partner = None
                if advertiser_name:
                    advertiser_key = ('advertiser', advertiser_name.lower(), advertiser_id or '')
                    if advertiser_key in resolved_partners_cache:
                        advertiser_partner, advertiser_status = resolved_partners_cache[advertiser_key]
                    else:
                        advertiser_partner, advertiser_status = self._resolve_partner(
                            advertiser_name, advertiser_id, is_agency=False,
                            sheet_data_dict=advertisers_data, log_lines=log_lines,
                            company=company
                        )
                        resolved_partners_cache[advertiser_key] = (advertiser_partner, advertiser_status)
                    advertiser_statuses[advertiser_partner.id] = advertiser_status

                # 6. Establish Parent-Child Hierarchy (Agency = Parent, Advertiser = Child)
                if agency_partner and advertiser_partner:
                    if agency_partner.id != advertiser_partner.id:
                        try:
                            advertiser_partner.write({
                                'parent_id': agency_partner.id,
                                'is_company': True,
                                'type': 'other'
                            })
                        except Exception as ex:
                            _logger.warning("Could not link parent agency %s to advertiser %s: %s", agency_partner.name, advertiser_partner.name, str(ex))
                            log_lines.append("Note: Linked advertiser %s as standalone company due to validation: %s" % (advertiser_partner.name, str(ex)))
                            advertiser_partner.write({
                                'is_company': True,
                                'type': 'other'
                            })
                    else:
                        advertiser_partner.write({
                            'is_company': True,
                            'parent_id': False,
                            'type': 'other'
                        })
                elif advertiser_partner:
                    advertiser_partner.write({
                        'is_company': True,
                        'parent_id': False,
                        'type': 'other'
                    })

                target_partner = advertiser_partner or agency_partner
                if not target_partner:
                    log_lines.append("Invoice %s: Missing Partner. Skipping." % invoice_number)
                    continue

                # Resolve Sale Journal and Account from cache
                journal = journal_cache.get(company.id)
                comp_accs = account_cache.get(company.id, {})
                account = comp_accs.get('1550') or comp_accs.get('income')

                net_amount_str = self._clean_str(self._get_row_val(row, [
                    'API_NET_AMOUNT', 'API_TOTAL_INVOICE_AMOUNT', 'NET_AMOUNT', 'TOTAL_INVOICE_AMOUNT', 
                    'RPA_Invoice Total', 'Net $', 'NET_AMOUNT (Mapped)', 'Invoice Total', 'NetAmount', 'Net'
                ])) or '0'
                try:
                    net_amount = float(str(net_amount_str).replace(',', '').strip())
                except Exception:
                    net_amount = 0.0

                line_vals = {
                    'name': self._clean_str(self._get_row_val(row, ['API_Order Product Description', 'RPA_Order Product Description', 'Product Description', 'Description'])) or 'WideOrbit Sync Line',
                    'quantity': 1.0,
                    'price_unit': net_amount,
                }
                if account:
                    line_vals['account_id'] = account.id

                invoice_vals = {
                    'move_type': 'out_invoice',
                    'ref': invoice_number,
                    'wideorbit_invoice_id': invoice_id,
                    'partner_id': target_partner.id,
                    'invoice_date': self._parse_date(self._get_row_val(row, ['API_INVOICE_DATE', 'INVOICE_DATE', 'Invoice Date', 'InvoiceDate', 'Create Date'])) or fields.Date.context_today(self),
                    'invoice_date_due': self._parse_date(self._get_row_val(row, ['API_DUE_DATE', 'DUE_DATE', 'Due Date', 'DueDate', 'End Date'])) or False,
                    'company_id': company.id,
                    'invoice_line_ids': [(0, 0, line_vals)]
                }
                if journal:
                    invoice_vals['journal_id'] = journal.id

                # Check if Invoice exists in Odoo by WideOrbit Unique ID first
                existing_invoice = False
                if invoice_id:
                    existing_invoice = self.env['account.move'].search([
                        ('wideorbit_invoice_id', '=', invoice_id)
                    ], limit=1)
                
                if not existing_invoice and invoice_number:
                    existing_invoice = self.env['account.move'].search([
                        ('wideorbit_invoice_id', '=', False),
                        ('ref', '=', invoice_number)
                    ], limit=1)

                move = False
                if existing_invoice:
                    if existing_invoice.state == 'draft':
                        # Update draft invoice fields: clear old lines and add new
                        existing_invoice.invoice_line_ids.unlink()
                        
                        update_vals = {
                            'ref': invoice_number,
                            'wideorbit_invoice_id': invoice_id,
                            'partner_id': target_partner.id,
                            'invoice_date': invoice_vals['invoice_date'],
                            'invoice_date_due': invoice_vals['invoice_date_due'],
                            'invoice_line_ids': [(0, 0, line_vals)]
                        }
                        if journal:
                            update_vals['journal_id'] = journal.id
                        
                        existing_invoice.with_context(
                            mail_notrack=True,
                            tracking_disable=True
                        ).write(update_vals)
                        log_lines.append("Updated draft invoice %s (Odoo ID: %s)" % (invoice_number, existing_invoice.id))
                        invoice_statuses[existing_invoice.id] = 'updated'
                        move = existing_invoice
                    else:
                        log_lines.append("Invoice %s already exists in Odoo (ID: %s) and is Posted. Skipping." % (invoice_number, existing_invoice.id))
                        invoice_statuses[existing_invoice.id] = 'skipped'
                else:
                    # Create draft invoice with suppressed mail logging for performance
                    move = self.env['account.move'].with_context(
                        mail_create_nolog=True,
                        mail_notrack=True,
                        tracking_disable=True
                    ).create(invoice_vals)
                    log_lines.append("Created invoice %s (Odoo ID: %s)" % (invoice_number, move.id))
                    invoice_statuses[move.id] = 'created'

                if move:
                    # Queue invoice for batch validation if fully paid
                    try:
                        balance_str = self._clean_str(self._get_row_val(row, ['API_OUTSTANDING_AMOUNT', 'Balance']))
                        balance = 1.0
                        if balance_str:
                            balance = float(balance_str.replace(',', '').strip())
                        
                        if balance == 0.0:
                            moves_to_post |= move
                    except Exception:
                        pass

            # Batch validate all paid invoices at once
            if moves_to_post:
                log_lines.append("Batch validating %d paid invoices..." % len(moves_to_post))
                try:
                    moves_to_post.action_post()
                    log_lines.append("Batch validation completed successfully.")
                except Exception as ex:
                    log_lines.append("Batch validation skipped (invoice left in draft): %s" % str(ex))

            # Attach PDFs if remote fetcher is active
            if fetcher:
                try:
                    self._attach_pdfs_to_invoices(fetcher, list(invoice_statuses.keys()), log_lines)
                except Exception as ex:
                    log_lines.append("Remote PDF synchronization skipped: %s" % str(ex))

            # Link any locally uploaded, unlinked PDF attachments to these invoices
            log_lines.append("Searching for locally uploaded unlinked PDF attachments...")
            synced_invoice_ids = list(invoice_statuses.keys())
            if synced_invoice_ids:
                invoices = self.env['account.move'].browse(synced_invoice_ids)
                for move in invoices:
                    ref = move.ref or ''
                    name = move.name or ''
                    
                    stems = []
                    if ref:
                        stems.append(ref.strip().lower())
                    if name:
                        stems.append(name.strip().lower())
                        
                    for stem in stems:
                        unlinked_attachments = self.env['ir.attachment'].search([
                            ('res_model', '=', False),
                            ('mimetype', '=', 'application/pdf'),
                            '|',
                            ('name', '=ilike', f"%{stem}%"),
                            ('name', 'ilike', stem)
                        ])
                        
                        if unlinked_attachments:
                            log_lines.append("Linking local PDF attachment %s to Invoice %s" % (unlinked_attachments[0].name, move.ref or move.id))
                            existing_linked = self.env['ir.attachment'].search([
                                ('res_model', '=', 'account.move'),
                                ('res_id', '=', move.id),
                                ('mimetype', '=', 'application/pdf')
                            ])
                            if existing_linked:
                                existing_linked.write({
                                    'name': unlinked_attachments[0].name,
                                    'datas': unlinked_attachments[0].datas
                                })
                                unlinked_attachments.unlink()
                            else:
                                unlinked_attachments[0].write({
                                    'res_model': 'account.move',
                                    'res_id': move.id
                                })
                            break

            log_lines.append("WideOrbit sync completed successfully.")

        except Exception as e:
            status = 'failed'
            log_lines.append("Sync Job Failed with exception: %s" % str(e))
            import traceback
            log_lines.append(traceback.format_exc())
            _logger.error("WideOrbit Sync failed: %s", str(e), exc_info=True)
        finally:
            if fetcher:
                try:
                    fetcher.close()
                except Exception:
                    pass

        # Compile unique statuses
        invoices_created = sum(1 for status in invoice_statuses.values() if status == 'created')
        invoices_updated = sum(1 for status in invoice_statuses.values() if status == 'updated')
        invoices_skipped = sum(1 for status in invoice_statuses.values() if status == 'skipped')

        agencies_created = sum(1 for status in agency_statuses.values() if status == 'created')
        agencies_updated = sum(1 for status in agency_statuses.values() if status == 'updated')
        agencies_skipped = sum(1 for status in agency_statuses.values() if status == 'skipped')

        advertisers_created = sum(1 for status in advertiser_statuses.values() if status == 'created')
        advertisers_updated = sum(1 for status in advertiser_statuses.values() if status == 'updated')
        advertisers_skipped = sum(1 for status in advertiser_statuses.values() if status == 'skipped')

        # Resolve files from the master workbook wizard if it was successfully instantiated
        rpa_inv = False
        rpa_inv_name = ''
        rpa_age = False
        rpa_age_name = ''
        rpa_adv = False
        rpa_adv_name = ''
        
        api_inv = False
        api_inv_name = ''
        api_age = False
        api_age_name = ''
        api_adv = False
        api_adv_name = ''

        if 'master_wb_wizard' in locals() and master_wb_wizard:
            rpa_inv = master_wb_wizard.rpa_invoice_file
            rpa_inv_name = master_wb_wizard.rpa_invoice_filename
            rpa_age = master_wb_wizard.rpa_agency_file
            rpa_age_name = master_wb_wizard.rpa_agency_filename
            rpa_adv = master_wb_wizard.rpa_advertiser_file
            rpa_adv_name = master_wb_wizard.rpa_advertiser_filename
            
            api_inv = master_wb_wizard.api_invoice_file
            api_inv_name = master_wb_wizard.api_invoice_filename
            api_age = master_wb_wizard.api_agency_file
            api_age_name = master_wb_wizard.api_agency_filename
            api_adv = master_wb_wizard.api_advertiser_file
            api_adv_name = master_wb_wizard.api_advertiser_filename

        # Auto-cleanup sync logs older than 7 days to preserve recent database fallbacks
        try:
            cleanup_date = fields.Datetime.now() - datetime.timedelta(days=7)
            older_sync_logs = self.env['wideorbit.sync.log'].search([
                ('sync_date', '<', cleanup_date)
            ])
            if older_sync_logs:
                older_sync_logs.write({
                    'rpa_invoice_file': False,
                    'rpa_agency_file': False,
                    'rpa_advertiser_file': False,
                    'api_invoice_file': False,
                    'api_agency_file': False,
                    'api_advertiser_file': False,
                })
        except Exception as e:
            _logger.warning(f"Failed to clear older sync log attachments: {e}")

        # Create Audit Log record
        self.env['wideorbit.sync.log'].create({
            'sync_date': fields.Datetime.now(),
            'sync_mode': 'remote',
            'status': status,
            'invoices_processed': invoices_processed,
            'invoices_created': invoices_created,
            'invoices_updated': invoices_updated,
            'invoices_skipped': invoices_skipped,
            'agencies_created': agencies_created,
            'agencies_updated': agencies_updated,
            'agencies_skipped': agencies_skipped,
            'advertisers_created': advertisers_created,
            'advertisers_updated': advertisers_updated,
            'advertisers_skipped': advertisers_skipped,
            'synced_invoice_ids': [(6, 0, list(invoice_statuses.keys()))],
            'synced_agency_ids': [(6, 0, list(agency_statuses.keys()))],
            'synced_advertiser_ids': [(6, 0, list(advertiser_statuses.keys()))],
            'rpa_invoice_file': rpa_inv,
            'rpa_invoice_filename': rpa_inv_name or 'INV_WO.xlsx',
            'rpa_agency_file': rpa_age,
            'rpa_agency_filename': rpa_age_name or 'Agency.xlsx',
            'rpa_advertiser_file': rpa_adv,
            'rpa_advertiser_filename': rpa_adv_name or 'Advertiser.xlsx',
            'api_invoice_file': api_inv,
            'api_invoice_filename': api_inv_name or 'Invoices.csv',
            'api_agency_file': api_age,
            'api_agency_filename': api_age_name or 'Agencies.csv',
            'api_advertiser_file': api_adv,
            'api_advertiser_filename': api_adv_name or 'Advertisers.csv',
            'details': "\n".join(log_lines)
        })

        # Return action to show logs
        action = self.env['ir.actions.actions']._for_xml_id('wideorbit_sync.action_wideorbit_sync_log')
        return action
