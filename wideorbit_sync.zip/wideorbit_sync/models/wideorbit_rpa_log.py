# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class RpaSyncLog(models.Model):
    _name = 'rpa.sync.log'
    _description = 'RPA Sync Log'
    _order = 'start_datetime desc, id desc'

    name = fields.Char(string='Reference', required=True, readonly=True, copy=False, default=lambda self: _('New'))
    start_datetime = fields.Datetime(string='Start Time', readonly=True)
    end_datetime = fields.Datetime(string='End Time', readonly=True)
    status = fields.Selection([
        ('success', 'Success'),
        ('failed', 'Failed')
    ], string='Status', required=True, readonly=True)
    billing_month = fields.Char(string='Billing Month', readonly=True)
    excel_uploaded = fields.Boolean(string='Excel Uploaded', readonly=True)
    invoice_uploaded = fields.Boolean(string='Invoices Uploaded', readonly=True)
    agency_uploaded = fields.Boolean(string='Agencies Uploaded', readonly=True)
    advertiser_uploaded = fields.Boolean(string='Advertisers Uploaded', readonly=True)
    pdfs_uploaded = fields.Boolean(string='PDFs Uploaded', readonly=True)
    pdfs_count = fields.Integer(string='PDFs Count', readonly=True)
    company_id = fields.Many2one('res.company', string='Company', readonly=True)
    exported_filename = fields.Char(string='Exported Filename', readonly=True)
    exported_records_count = fields.Integer(string='Exported Records Count', readonly=True)
    details = fields.Text(string='Log Details', readonly=True)

    # Synced RPA Excel Files
    invoice_file = fields.Binary(string='Invoices Excel File', readonly=True)
    invoice_filename = fields.Char(string='Invoices Excel Filename', readonly=True)
    agency_file = fields.Binary(string='Agencies Excel File', readonly=True)
    agency_filename = fields.Char(string='Agencies Excel Filename', readonly=True)
    advertiser_file = fields.Binary(string='Advertisers Excel File', readonly=True)
    advertiser_filename = fields.Char(string='Advertisers Excel Filename', readonly=True)

    @api.model_create_multi
    def create(self, vals_list):
        from datetime import timedelta
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                run_date = vals.get('start_datetime') or fields.Datetime.now()
                dt = fields.Datetime.to_datetime(run_date)
                date_start = dt.replace(hour=0, minute=0, second=0, microsecond=0)
                date_end = date_start + timedelta(days=1)
                
                todays_count = self.search_count([
                    ('start_datetime', '>=', date_start),
                    ('start_datetime', '<', date_end)
                ])
                next_seq = todays_count + 1
                date_path = fields.Datetime.context_timestamp(self, dt).strftime('%Y/%m/%d')
                vals['name'] = f"RPA/{date_path}/{next_seq:03d}"
        return super(RpaSyncLog, self).create(vals_list)
