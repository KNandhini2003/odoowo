from odoo import models, fields

class WideOrbitSyncLog(models.Model):
    _name = 'wideorbit.sync.log'
    _description = 'WideOrbit Sync Audit Log'
    _order = 'sync_date desc'

    sync_date = fields.Datetime(
        string='Sync Date',
        default=fields.Datetime.now,
        readonly=True
    )
    sync_mode = fields.Selection([
        ('local', 'Local Directory Path'),
        ('upload', 'Manual File Upload'),
        ('remote', 'Remote Source Sync')
    ], string='Sync Mode', readonly=True)
    
    status = fields.Selection([
        ('success', 'Success'),
        ('failed', 'Failed')
    ], string='Status', readonly=True)
    
    invoices_processed = fields.Integer(string='Invoices Processed', readonly=True)
    invoices_created = fields.Integer(string='Invoices Created', readonly=True)
    invoices_updated = fields.Integer(string='Invoices Updated', readonly=True)
    invoices_skipped = fields.Integer(string='Invoices Skipped', readonly=True)

    agencies_created = fields.Integer(string='Agencies Created', readonly=True)
    agencies_updated = fields.Integer(string='Agencies Updated', readonly=True)
    agencies_skipped = fields.Integer(string='Agencies Skipped', readonly=True)

    advertisers_created = fields.Integer(string='Advertisers Created', readonly=True)
    advertisers_updated = fields.Integer(string='Advertisers Updated', readonly=True)
    advertisers_skipped = fields.Integer(string='Advertisers Skipped', readonly=True)
    
    details = fields.Text(string='Log Details', readonly=True)

    # Synced File Attachments
    rpa_invoice_file = fields.Binary(string='RPA Invoice File', readonly=True)
    rpa_invoice_filename = fields.Char(string='RPA Invoice Filename', readonly=True)
    rpa_agency_file = fields.Binary(string='RPA Agency File', readonly=True)
    rpa_agency_filename = fields.Char(string='RPA Agency Filename', readonly=True)
    rpa_advertiser_file = fields.Binary(string='RPA Advertiser File', readonly=True)
    rpa_advertiser_filename = fields.Char(string='RPA Advertiser Filename', readonly=True)

    api_invoice_file = fields.Binary(string='API Invoice File', readonly=True)
    api_invoice_filename = fields.Char(string='API Invoice Filename', readonly=True)
    api_agency_file = fields.Binary(string='API Agency File', readonly=True)
    api_agency_filename = fields.Char(string='API Agency Filename', readonly=True)
    api_advertiser_file = fields.Binary(string='API Advertiser File', readonly=True)
    api_advertiser_filename = fields.Char(string='API Advertiser Filename', readonly=True)

    # Relations to synced records
    synced_invoice_ids = fields.Many2many(
        'account.move',
        'wideorbit_sync_log_invoice_rel',
        'log_id', 'move_id',
        string='Synced Invoices',
        readonly=True
    )
    synced_agency_ids = fields.Many2many(
        'res.partner',
        'wideorbit_sync_log_agency_rel',
        'log_id', 'partner_id',
        string='Synced Agencies',
        readonly=True
    )
    synced_advertiser_ids = fields.Many2many(
        'res.partner',
        'wideorbit_sync_log_advertiser_rel',
        'log_id', 'partner_id',
        string='Synced Advertisers',
        readonly=True
    )
