# -*- coding: utf-8 -*-
import io
import base64
import logging
import re
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False
    _logger.warning("openpyxl is not installed. Master Workbook generator will not be functional.")


class WideOrbitMasterWorkbook(models.TransientModel):
    _name = 'wideorbit.master.workbook'
    _description = 'Generate WideOrbit Master Mapping Workbook'

    def _default_source_config(self):
        try:
            return self.env['wideorbit.source.config'].sudo().get_config()
        except Exception:
            return False

    source_config_id = fields.Many2one(
        'wideorbit.source.config',
        string='Source Configuration',
        default=_default_source_config,
        required=True
    )

    rpa_invoice_file = fields.Binary(string='RPA Invoice File')
    rpa_invoice_filename = fields.Char(string='RPA Invoice Filename')
    rpa_agency_file = fields.Binary(string='RPA Agency File')
    rpa_agency_filename = fields.Char(string='RPA Agency Filename')
    rpa_advertiser_file = fields.Binary(string='RPA Advertiser File')
    rpa_advertiser_filename = fields.Char(string='RPA Advertiser Filename')

    api_invoice_file = fields.Binary(string='API Invoice File')
    api_invoice_filename = fields.Char(string='API Invoice Filename')
    api_agency_file = fields.Binary(string='API Agency File')
    api_agency_filename = fields.Char(string='API Agency Filename')
    api_advertiser_file = fields.Binary(string='API Advertiser File')
    api_advertiser_filename = fields.Char(string='API Advertiser Filename')

    def action_debug_parse(self):
        self.ensure_one()
        sync_wizard = self.env['wideorbit.sync']
        if not self.rpa_invoice_file:
            return "rpa_invoice_file is False"
        try:
            res = sync_wizard._read_file_data(binary_data=self.rpa_invoice_file, filename=self.rpa_invoice_filename or 'INV_WO.xlsx')
            return "SUCCESS: Rows count: %s, First keys: %s" % (len(res), list(res[0].keys()) if res else [])
        except Exception as e:
            import traceback
            return "ERROR: %s\n%s" % (str(e), traceback.format_exc())

    def _generate_workbook_object(self):
        self.ensure_one()
        if not OPENPYXL_AVAILABLE:
            raise UserError(_("Python library 'openpyxl' is not installed in the environment. Please run 'pip install openpyxl' to enable this feature."))

        sync_wizard = self.env['wideorbit.sync']
        def safe_decode_base64(data):
            if not data:
                return b''
            if isinstance(data, str):
                try:
                    return base64.b64decode(data.strip())
                except Exception:
                    return data.encode('utf-8')
            if isinstance(data, bytes):
                if data.startswith(b'PK\x03\x04') or data.startswith(b'\xd0\xcf\x11\xe0'):
                    return data
                # Only trust a base64 decode if the input is STRICTLY valid base64
                # (validate=True rejects any character outside the base64 alphabet,
                # e.g. spaces, commas, '#', newlines found in real CSV/text content).
                # Previously this only accepted the decode when the *result* looked
                # like an xlsx/xls binary signature, which silently left genuine
                # base64-encoded CSV/text content un-decoded (garbled data).
                try:
                    # Strip any whitespace/newlines before validation
                    cleaned_data = re.sub(rb'\s+', b'', data)
                    decoded = base64.b64decode(cleaned_data, validate=True)
                    return decoded
                except Exception:
                    pass
                return data
            return data


        # 1. Initialize file data bytes
        rpa_inv_bytes = safe_decode_base64(self.rpa_invoice_file) if self.rpa_invoice_file else None
        rpa_agency_bytes = safe_decode_base64(self.rpa_agency_file) if self.rpa_agency_file else None
        rpa_adv_bytes = safe_decode_base64(self.rpa_advertiser_file) if self.rpa_advertiser_file else None

        api_inv_bytes = base64.b64decode(self.api_invoice_file) if self.api_invoice_file else None
        api_agency_bytes = base64.b64decode(self.api_agency_file) if self.api_agency_file else None
        api_adv_bytes = base64.b64decode(self.api_advertiser_file) if self.api_advertiser_file else None

        # 2. Try to fetch from the latest RPA/API sync logs inside Odoo first (Local Database)
        if not rpa_inv_bytes:
            latest_rpa_log = self.env['rpa.sync.log'].search([
                ('invoice_file', '!=', False)
            ], limit=1, order='id desc')
            if latest_rpa_log:
                rpa_inv_bytes = safe_decode_base64(latest_rpa_log.invoice_file)
                rpa_agency_bytes = safe_decode_base64(latest_rpa_log.agency_file) if latest_rpa_log.agency_file else None
                rpa_adv_bytes = safe_decode_base64(latest_rpa_log.advertiser_file) if latest_rpa_log.advertiser_file else None
                
                # Write back to wizard fields
                self.write({
                    'rpa_invoice_file': latest_rpa_log.invoice_file,
                    'rpa_invoice_filename': latest_rpa_log.invoice_filename,
                    'rpa_agency_file': latest_rpa_log.agency_file,
                    'rpa_agency_filename': latest_rpa_log.agency_filename,
                    'rpa_advertiser_file': latest_rpa_log.advertiser_file,
                    'rpa_advertiser_filename': latest_rpa_log.advertiser_filename,
                })

        if not api_inv_bytes:
            latest_api_log = self.env['api.sync.log'].search([
                ('invoice_file', '!=', False)
            ], limit=1, order='id desc')
            if latest_api_log:
                api_inv_bytes = safe_decode_base64(latest_api_log.invoice_file)
                api_agency_bytes = safe_decode_base64(latest_api_log.agency_file) if latest_api_log.agency_file else None
                api_adv_bytes = safe_decode_base64(latest_api_log.advertiser_file) if latest_api_log.advertiser_file else None
                
                # Write back to wizard fields
                self.write({
                    'api_invoice_file': latest_api_log.invoice_file,
                    'api_invoice_filename': latest_api_log.invoice_filename,
                    'api_agency_file': latest_api_log.agency_file,
                    'api_agency_filename': latest_api_log.agency_filename,
                    'api_advertiser_file': latest_api_log.advertiser_file,
                    'api_advertiser_filename': latest_api_log.advertiser_filename,
                })

        # 3. Fallback to remote source config only if files are still missing
        if not rpa_inv_bytes or not api_inv_bytes:
            _logger.info("Master Workbook: Local database logs empty. Falling back to remote source fetcher...")
            config = self.source_config_id
            fetcher = config._get_fetcher()
            if not fetcher.connect():
                raise UserError(_("Failed to connect to the remote source. Please check the configuration details and test connection first."))

            if config.data_source == 'sftp':
                rpa_folder = config.sftp_rpa_dir or '/wideorbit/rpa'
                api_folder = config.sftp_api_dir or '/wideorbit/api'
            else:
                rpa_folder = config.sp_rpa_folder or '/7 - 910 Media/Wideorbit/RPA'
                api_folder = config.sp_api_folder or '/7 - 910 Media/Wideorbit/API'

            rpa_files = fetcher.list_files(rpa_folder)
            api_files = fetcher.list_files(api_folder)

            def find_file_by_patterns(files, patterns):
                matched = []
                for file_info in files:
                    filename = file_info['name'].lower()
                    for pat in patterns:
                        if re.search(pat, filename):
                            matched.append(file_info)
                            break
                if matched:
                    matched.sort(key=lambda x: x['name'], reverse=True)
                    return matched[0]
                return None

            rpa_invoice_file = find_file_by_patterns(rpa_files, [r'invoice.*\.xlsx$', r'inv_wo.*\.xlsx$', r'adv_wo.*\.xlsx$', r'inv.*\.xlsx$'])
            rpa_agency_file = find_file_by_patterns(rpa_files, [r'agenc.*\.xlsx$'])
            rpa_advertiser_file = find_file_by_patterns(rpa_files, [r'advertis.*\.xlsx$'])

            api_invoice_file = find_file_by_patterns(api_files, [r'invoice.*\.csv$', r'inv_wo.*\.csv$', r'adv_wo.*\.csv$', r'inv.*\.csv$'])
            api_agency_file = find_file_by_patterns(api_files, [r'agenc.*\.csv$'])
            api_advertiser_file = find_file_by_patterns(api_files, [r'advertis.*\.csv$'])

            if not rpa_inv_bytes and rpa_invoice_file:
                rpa_inv_bytes = fetcher.download_file(rpa_invoice_file['path'])
                rpa_agency_bytes = fetcher.download_file(rpa_agency_file['path']) if rpa_agency_file else None
                rpa_adv_bytes = fetcher.download_file(rpa_advertiser_file['path']) if rpa_advertiser_file else None
                self.write({
                    'rpa_invoice_file': base64.b64encode(rpa_inv_bytes) if rpa_inv_bytes else False,
                    'rpa_invoice_filename': rpa_invoice_file['name'] if rpa_invoice_file else '',
                    'rpa_agency_file': base64.b64encode(rpa_agency_bytes) if rpa_agency_bytes else False,
                    'rpa_agency_filename': rpa_agency_file['name'] if rpa_agency_file else '',
                    'rpa_advertiser_file': base64.b64encode(rpa_adv_bytes) if rpa_adv_bytes else False,
                    'rpa_advertiser_filename': rpa_advertiser_file['name'] if rpa_advertiser_file else '',
                })

            if not api_inv_bytes and api_invoice_file:
                api_inv_bytes = fetcher.download_file(api_invoice_file['path'])
                api_agency_bytes = fetcher.download_file(api_agency_file['path']) if api_agency_file else None
                api_adv_bytes = fetcher.download_file(api_advertiser_file['path']) if api_advertiser_file else None
                self.write({
                    'api_invoice_file': base64.b64encode(api_inv_bytes) if api_inv_bytes else False,
                    'api_invoice_filename': api_invoice_file['name'] if api_invoice_file else '',
                    'api_agency_file': base64.b64encode(api_agency_bytes) if api_agency_bytes else False,
                    'api_agency_filename': api_agency_file['name'] if api_agency_file else '',
                    'api_advertiser_file': base64.b64encode(api_adv_bytes) if api_adv_bytes else False,
                    'api_advertiser_filename': api_advertiser_file['name'] if api_advertiser_file else '',
                })

            fetcher.close()

        if not rpa_inv_bytes and not api_inv_bytes:
            raise UserError(_("No RPA or API invoice data found to generate the Master Workbook. Please run the RPA bot or API export sync first to populate data."))

        # Helper to convert downloaded bytes to parsed lists of dictionaries
        def parse_file(binary_content, filename):
            if not binary_content or len(binary_content) < 100:
                return []
            try:
                # Pass the raw bytes straight through. _read_file_data's own
                # safe_decode_base64() only trusts a base64 round-trip when the
                # decoded content matches an xlsx/xls binary signature (PK../OLE).
                # CSV/text content never matches that signature, so pre-encoding it
                # to base64 here caused it to come back out as an un-decoded base64
                # string instead of real CSV text (garbled headers/rows, no data).
                return sync_wizard._read_file_data(binary_data=binary_content, filename=filename)
            except Exception as e:
                _logger.warning("Master Workbook: Skipping invalid or corrupted file '%s': %s", filename, e)
                return []

        # 5. Parse downloaded files
        _logger.info("Master Workbook: Parsing downloaded data sheets...")
        rpa_inv_data = parse_file(rpa_inv_bytes, self.rpa_invoice_filename or 'INV_WO.xlsx')
        api_inv_data = parse_file(api_inv_bytes, self.api_invoice_filename or 'Invoices.csv')

        rpa_agency_data = parse_file(rpa_agency_bytes, self.rpa_agency_filename or 'Agency.xlsx') if rpa_agency_bytes else []
        api_agency_data = parse_file(api_agency_bytes, self.api_agency_filename or 'Agencies.csv') if api_agency_bytes else []

        rpa_adv_data = parse_file(rpa_adv_bytes, self.rpa_advertiser_filename or 'Advertiser.xlsx') if rpa_adv_bytes else []
        api_adv_data = parse_file(api_adv_bytes, self.api_advertiser_filename or 'Advertisers.csv') if api_adv_bytes else []

        # Helper to get exact cell value lookups
        def get_row_value(row, keys_to_try, entity_name=None):
            keys_lower = [k.lower().strip() for k in keys_to_try]
            # 1. Exact match (case-insensitive & stripped)
            for key, val in row.items():
                if str(key).lower().strip() in keys_lower:
                    return val
            # 2. Substring match fallback (matching generate_master_workbook.py logic)
            if entity_name:
                for key, val in row.items():
                    if entity_name.lower() in str(key).lower():
                        return val
            return None

        # Resilient key normalization helper
        def get_clean_key(row, keys_to_try, entity_name=None):
            val = get_row_value(row, keys_to_try, entity_name)
            if val is None:
                return None
            s = str(val).strip().lower()
            s = re.sub(r'\s+', ' ', s)
            return s

        # 6. Consolidation and merge logic matching reference script generate_master_workbook.py
        def consolidate_sheet(rpa_list, api_list, rpa_keys, api_keys, entity_name):
            # Clean and filter RPA rows
            rpa_cleaned = []
            rpa_headers = []
            if rpa_list:
                rpa_headers = list(rpa_list[0].keys())
                for idx, row in enumerate(rpa_list):
                    val = get_row_value(row, rpa_keys, entity_name)
                    val_str = str(val).strip() if val is not None else ''
                    if val_str == '' or val_str.lower() in ('total', 'grand total', 'summary'):
                        continue
                    rpa_cleaned.append(row)

            # Build match index for API rows
            api_dedup = {}
            api_headers = []
            if api_list:
                api_headers = list(api_list[0].keys())
                for row in api_list:
                    val = get_row_value(row, api_keys, entity_name)
                    if val is not None:
                        key_clean = str(val).strip().upper()
                        if key_clean and key_clean not in api_dedup:
                            api_dedup[key_clean] = row

            # Merge RPA base records with matching API records
            rows_data = []
            for rpa_row in rpa_cleaned:
                val = get_row_value(rpa_row, rpa_keys, entity_name)
                key_clean = str(val).strip().upper() if val is not None else ''
                api_row = api_dedup.get(key_clean)
                
                # Combine row dict
                combined = {}
                # Add RPA fields
                for col in rpa_headers:
                    combined[f"[RPA] {col}"] = rpa_row.get(col)
                # Add API fields (only if not already in RPA headers, case-insensitive check)
                rpa_headers_lower = [h.lower() for h in rpa_headers]
                for col in api_headers:
                    if col.lower() not in rpa_headers_lower:
                        combined[f"[API] {col}"] = api_row.get(col) if api_row else ''
                rows_data.append(combined)

            # Determine final headers list
            final_headers = []
            rpa_cols_count = len(rpa_headers)
            for col in rpa_headers:
                final_headers.append(f"[RPA] {col}")
            rpa_headers_lower = [h.lower() for h in rpa_headers]
            for col in api_headers:
                if col.lower() not in rpa_headers_lower:
                    final_headers.append(f"[API] {col}")

            return rows_data, final_headers, rpa_cols_count

        # Perform consolidated merges
        invoice_keys = ['Invoice #', 'InvoiceNo', 'Invoice Number', 'INVOICE_NUMBER', 'INVOICE_ID (Mapped)', 'INV_NO', 'INV#', 'InvoiceID', 'Invoice ID', 'Invoice']
        agency_keys = ['Agency Name (Mapped)', 'Agency Name', 'Agency', 'AGENCY_NAME', 'Agency_Name', 'Reporting Agency']
        advertiser_keys = ['Advertiser Name (Mapped)', 'Advertiser Name', 'Advertiser', 'ADVERTISER_NAME', 'Advertiser_Name', 'Reporting Advertiser']

        inv_rows, inv_headers, inv_rpa_count = consolidate_sheet(rpa_inv_data, api_inv_data, invoice_keys, invoice_keys, 'Invoice')
        agency_rows, agency_headers, agency_rpa_count = consolidate_sheet(rpa_agency_data, api_agency_data, agency_keys, agency_keys, 'Agency')
        adv_rows, adv_headers, adv_rpa_count = consolidate_sheet(rpa_adv_data, api_adv_data, advertiser_keys, advertiser_keys, 'Advertiser')

        # 7. Create Workbook in openpyxl matching reference styling
        _logger.info("Master Workbook: Generating openpyxl file...")
        wb = Workbook()

        # Styles matching reference script
        header_font = Font(name='Segoe UI', size=11, bold=True, color='FFFFFF')
        rpa_fill = PatternFill(start_color='1F4E78', end_color='1F4E78', fill_type='solid') # Navy Blue
        api_fill = PatternFill(start_color='274E13', end_color='274E13', fill_type='solid') # Dark Green
        center_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
        thin_border = Border(
            left=Side(style='thin', color='FFFFFF'),
            right=Side(style='thin', color='FFFFFF'),
            top=Side(style='thin', color='FFFFFF'),
            bottom=Side(style='medium', color='000000')
        )

        def write_consolidated_sheet(sheet_name, rows_data, headers, rpa_cols_count):
            ws = wb.create_sheet(title=sheet_name)
            
            # Sanitizer pattern for openpyxl illegal XML characters
            illegal_chars_re = re.compile(r'[\000-\010]|[\013-\014]|[\016-\037]')
            def clean_value(val):
                if val is None:
                    return ''
                if isinstance(val, str):
                    return illegal_chars_re.sub('', val)
                return val

            # Write Headers
            for col_idx, h in enumerate(headers, 1):
                cell = ws.cell(row=1, column=col_idx, value=clean_value(h))
                cell.font = header_font
                cell.fill = rpa_fill if col_idx <= rpa_cols_count else api_fill
                cell.alignment = center_align
                cell.border = thin_border

            # Freeze Panes at A2
            ws.freeze_panes = 'A2'

            # Write Data Rows
            for row_idx, row_dict in enumerate(rows_data, 2):
                for col_idx, h in enumerate(headers, 1):
                    ws.cell(row=row_idx, column=col_idx, value=clean_value(row_dict.get(h)))

            # Auto-fit column widths (cap width at 50 to prevent Excel validation errors)
            for col in ws.columns:
                max_len = max(len(str(cell.value or '')) for cell in col)
                col_letter = get_column_letter(col[0].column)
                ws.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 50)

        # Write each worksheet
        write_consolidated_sheet('Invoice', inv_rows, inv_headers, inv_rpa_count)
        write_consolidated_sheet('Agency', agency_rows, agency_headers, agency_rpa_count)
        write_consolidated_sheet('Advertiser', adv_rows, adv_headers, adv_rpa_count)

        # Remove default active sheet if it's empty
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
        
        # Explicitly set the first sheet as active to prevent Excel XML corruption
        if wb.sheetnames:
            wb.active = wb.worksheets[0]

        return wb

    def action_generate_workbook(self):
        self.ensure_one()
        wb = self._generate_workbook_object()

        # Save workbook to BytesIO
        output = io.BytesIO()
        wb.save(output)
        file_data = output.getvalue()
        output.close()

        # 8. Create Odoo attachment and return download action
        _logger.info("Master Workbook: Creating attachment...")
        attachment = self.env['ir.attachment'].create({
            'name': 'WO_Master_Mapping_Workbook.xlsx',
            'type': 'binary',
            'datas': base64.b64encode(file_data),
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        })

        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{attachment.id}?download=true',
            'target': 'new',
        }
