# -*- coding: utf-8 -*-
import os
from odoo import http, release
from odoo.http import request

# Resolve the route type dynamically to prevent DeprecationWarnings on Odoo 19+ 
# while maintaining backward compatibility with Odoo 17 and 18.
route_type = 'json'
try:
    version_str = release.version.split('+')[0]
    version_parts = [int(x) for x in version_str.split('.') if x.isdigit()]
    if version_parts and version_parts[0] >= 19:
        route_type = 'jsonrpc'
except Exception:
    pass

class WideOrbitRpaController(http.Controller):

    @http.route('/wideorbit_sync/rpa/log_run', type=route_type, auth='public', methods=['POST'], csrf=False)
    def log_rpa_run(self, **kwargs):
        """Webhook API endpoint to receive logs from the local BotCity bot.
        Expects payload in JSON-RPC format:
        {
            "jsonrpc": "2.0",
            "method": "call",
            "params": {
                "status": "success/failed",
                "start_datetime": "YYYY-MM-DD HH:MM:SS",
                "end_datetime": "YYYY-MM-DD HH:MM:SS",
                "billing_month": "July",
                "excel_uploaded": true,
                "pdfs_uploaded": true,
                "pdfs_count": 1,
                "company_name": "910 Media Group",
                "exported_filename": "INV_WO_20260716_123105.xlsx",
                "exported_records_count": 1,
                "details": "stdout logs..."
            }
        }
        """
        params = request.params or {}

        # Resolve upload statuses
        excel_uploaded = bool(params.get('excel_uploaded'))
        invoice_uploaded = bool(params.get('invoice_uploaded') or excel_uploaded)
        agency_uploaded = bool(params.get('agency_uploaded') or params.get('agency_excel_uploaded'))
        advertiser_uploaded = bool(params.get('advertiser_uploaded') or params.get('advertiser_excel_uploaded'))
        pdfs_uploaded = bool(params.get('pdfs_uploaded'))

        # If any of the required processes missed uploading, set status to failed
        status = 'success'
        if not (invoice_uploaded and agency_uploaded and advertiser_uploaded and pdfs_uploaded):
            status = 'failed'

        # Resolve company_id from company_name
        company_id = False
        company_name = params.get('company_name')
        if company_name:
            company = request.env['res.company'].sudo().search([('name', 'ilike', company_name)], limit=1)
            if company:
                company_id = company.id
        if not company_id:
            # Fallback to Odoo default company
            company_id = request.env.company.id

        # Create RPA Export Log record in Odoo directly
        vals = {
            'status': status,
            'start_datetime': params.get('start_datetime'),
            'end_datetime': params.get('end_datetime'),
            'billing_month': params.get('billing_month'),
            'excel_uploaded': excel_uploaded,
            'invoice_uploaded': invoice_uploaded,
            'agency_uploaded': agency_uploaded,
            'advertiser_uploaded': advertiser_uploaded,
            'pdfs_uploaded': pdfs_uploaded,
            'pdfs_count': int(params.get('pdfs_count', 0)),
            'company_id': company_id,
            'exported_filename': params.get('exported_filename'),
            'exported_records_count': int(params.get('exported_records_count', 0)),
            'details': params.get('details'),
            'invoice_file': params.get('invoices_xlsx'),
            'invoice_filename': params.get('invoices_filename', 'INV_WO.xlsx'),
            'agency_file': params.get('agencies_xlsx'),
            'agency_filename': params.get('agencies_filename', 'Agency.xlsx'),
            'advertiser_file': params.get('advertisers_xlsx'),
            'advertiser_filename': params.get('advertisers_filename', 'Advertiser.xlsx'),
        }
        log_record = request.env['rpa.sync.log'].sudo().create(vals)

        # Auto-cleanup old log attachments to save disk space
        try:
            older_logs = request.env['rpa.sync.log'].sudo().search([('id', '!=', log_record.id)])
            if older_logs:
                older_logs.write({
                    'invoice_file': False,
                    'agency_file': False,
                    'advertiser_file': False
                })
        except Exception as e:
            _logger.warning(f"Failed to clear older RPA log attachments: {e}")

        return {
            'status': 'success',
            'log_id': log_record.id,
            'log_name': log_record.name
        }

    @http.route('/wideorbit_sync/api/log_run', type=route_type, auth='public', methods=['POST'], csrf=False)
    def log_api_run(self, **kwargs):
        """Webhook API endpoint to receive logs from Odoo's internal sync/wizard API.
        Expects payload in JSON-RPC format:
        {
            "jsonrpc": "2.0",
            "method": "call",
            "params": {
                "status": "success/failed",
                "invoice_uploaded": true,
                "agency_uploaded": true,
                "advertiser_uploaded": true,
                "excel_uploaded": true,
                "start_datetime": "YYYY-MM-DD HH:MM:SS",
                "end_datetime": "YYYY-MM-DD HH:MM:SS",
                "billing_month": "July 2026",
                "company_name": "My Company (San Francisco)",
                "details": "stdout logs..."
            }
        }
        """
        params = request.params or {}

        # Validate status value
        status = params.get('status')
        if status not in ('success', 'failed'):
            status = 'failed'

        # Resolve company_id from company_name
        company_id = False
        company_name = params.get('company_name')
        if company_name:
            company = request.env['res.company'].sudo().search([('name', 'ilike', company_name)], limit=1)
            if company:
                company_id = company.id
        if not company_id:
            # Fallback to Odoo default company
            company_id = request.env.company.id

        # Fallback mapping: if invoice_uploaded is not provided, map excel_uploaded to it
        invoice_uploaded = params.get('invoice_uploaded')
        excel_uploaded = params.get('excel_uploaded')
        if invoice_uploaded is None and excel_uploaded is not None:
            invoice_uploaded = excel_uploaded

        # Create API Sync Log record in Odoo directly
        vals = {
            'status': status,
            'start_datetime': params.get('start_datetime'),
            'end_datetime': params.get('end_datetime'),
            'billing_month': params.get('billing_month'),
            'invoice_uploaded': bool(invoice_uploaded),
            'agency_uploaded': bool(params.get('agency_uploaded')),
            'advertiser_uploaded': bool(params.get('advertiser_uploaded')),
            'excel_uploaded': bool(excel_uploaded),
            'company_id': company_id,
            'details': params.get('details'),
            'invoice_file': params.get('invoices_csv'),
            'invoice_filename': params.get('invoices_filename', 'Invoices.csv'),
            'agency_file': params.get('agencies_csv'),
            'agency_filename': params.get('agencies_filename', 'Agencies.csv'),
            'advertiser_file': params.get('advertisers_csv'),
            'advertiser_filename': params.get('advertisers_filename', 'Advertisers.csv'),
        }
        log_record = request.env['api.sync.log'].sudo().create(vals)

        # Auto-cleanup old log attachments to save disk space
        try:
            older_logs = request.env['api.sync.log'].sudo().search([('id', '!=', log_record.id)])
            if older_logs:
                older_logs.write({
                    'invoice_file': False,
                    'agency_file': False,
                    'advertiser_file': False
                })
        except Exception as e:
            _logger.warning(f"Failed to clear older API log attachments: {e}")

        return {
            'status': 'success',
            'log_id': log_record.id,
            'log_name': log_record.name
        }

    @http.route('/wideorbit_sync/download_bot', type='http', auth='public', methods=['GET'], csrf=False)
    def download_bot(self):
        """Serves the BotCity RPA zip bundle as a binary download attachment."""
        # Find absolute path of the file inside the module
        addon_path = os.path.dirname(os.path.dirname(__file__))
        zip_path = os.path.join(addon_path, 'static', 'src', 'rpa', 'wideorbit-invoice-export-bot.zip')

        if not os.path.exists(zip_path):
            return request.not_found()

        with open(zip_path, 'rb') as f:
            data = f.read()

        headers = [
            ('Content-Type', 'application/zip'),
            ('Content-Disposition', 'attachment; filename="wideorbit-invoice-export-bot.zip"')
        ]
        return request.make_response(data, headers=headers)

    @http.route('/wideorbit_sync/api/upload_data', type=route_type, auth='public', methods=['POST'], csrf=False)
    def upload_data(self, **kwargs):
        """Webhook API endpoint to receive exported files directly from external scripts.
        Expects payload in JSON-RPC format:
        {
            "jsonrpc": "2.0",
            "method": "call",
            "params": {
                "invoices_csv": "<base64_encoded_Invoices.csv>",
                "invoices_filename": "Invoices.csv",
                "agencies_csv": "<base64_encoded_Agencies.csv>",
                "agencies_filename": "Agencies.csv",
                "advertisers_csv": "<base64_encoded_Advertisers.csv>",
                "advertisers_filename": "Advertisers.csv",
                "company_name": "My Company (San Francisco)"
            }
        }
        """
        params = request.params or {}
        
        invoices_csv = params.get('invoices_csv')
        agencies_csv = params.get('agencies_csv')
        advertisers_csv = params.get('advertisers_csv')
        
        if not all([invoices_csv, agencies_csv, advertisers_csv]):
            return {
                'status': 'error',
                'message': 'Missing required base64 file data for invoices, agencies, or advertisers.'
            }
            
        # Resolve company
        company_id = False
        company_name = params.get('company_name')
        if company_name:
            company = request.env['res.company'].sudo().search([('name', 'ilike', company_name)], limit=1)
            if company:
                company_id = company.id
        if not company_id:
            company_id = request.env.company.id
            
        try:
            import datetime
            # Create a log record to store the uploaded files so that the sync wizard can find them
            log_vals = {
                'status': 'success',
                'start_datetime': datetime.datetime.now(),
                'end_datetime': datetime.datetime.now(),
                'billing_month': datetime.datetime.now().strftime("%B %Y"),
                'invoice_uploaded': True,
                'agency_uploaded': True,
                'advertiser_uploaded': True,
                'excel_uploaded': True,
                'company_id': company_id,
                'invoice_file': invoices_csv,
                'invoice_filename': params.get('invoices_filename', 'Invoices.csv'),
                'agency_file': agencies_csv,
                'agency_filename': params.get('agencies_filename', 'Agencies.csv'),
                'advertiser_file': advertisers_csv,
                'advertiser_filename': params.get('advertisers_filename', 'Advertisers.csv'),
            }
            request.env['api.sync.log'].sudo().create(log_vals)

            # Execute sync with company context
            wizard = request.env['wideorbit.sync'].sudo().with_company(company_id).create({})
            wizard.action_run_sync()
            
            return {
                'status': 'success',
                'message': 'Data successfully uploaded and synchronized in Odoo.'
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Sync execution failed: {str(e)}'
            }

    @http.route('/wideorbit_sync/rpa/upload_pdf', type=route_type, auth='public', methods=['POST'], csrf=False)
    def upload_pdf(self, **kwargs):
        """Webhook API endpoint to receive scraped PDFs directly from BotCity RPA.
        Expects payload in JSON-RPC format:
        {
            "jsonrpc": "2.0",
            "method": "call",
            "params": {
                "pdf_data": "<base64_encoded_pdf>",
                "pdf_name": "INV_10023.pdf",
                "company_name": "My Company (San Francisco)"
            }
        }
        """
        params = request.params or {}
        pdf_data = params.get('pdf_data')
        pdf_name = params.get('pdf_name')
        
        if not pdf_data or not pdf_name:
            return {
                'status': 'error',
                'message': 'Missing required base64 file data or file name.'
            }
            
        # Resolve company
        company_id = False
        company_name = params.get('company_name')
        if company_name:
            company = request.env['res.company'].sudo().search([('name', 'ilike', company_name)], limit=1)
            if company:
                company_id = company.id
        if not company_id:
            company_id = request.env.company.id
            
        try:
            # 1. Clean PDF name to find matching invoice
            # Stem name (e.g. "INV_10023" from "INV_10023.pdf")
            pdf_stem = os.path.splitext(pdf_name)[0].strip()
            
            # Find matching invoices
            # We match invoice by `ref` (reference) or `name` (Odoo number) using the PDF name stem
            invoice = request.env['account.move'].sudo().with_company(company_id).search([
                '|',
                ('ref', '=ilike', pdf_stem),
                ('name', '=ilike', pdf_stem)
            ], limit=1)
            
            if not invoice:
                # Fallback: check if the stem is a suffix or part of ref (e.g., if stem is "10023" and ref is "INV_10023")
                invoice = request.env['account.move'].sudo().with_company(company_id).search([
                    '|',
                    ('ref', 'ilike', pdf_stem),
                    ('name', 'ilike', pdf_stem)
                ], limit=1)
                
            if not invoice:
                # Save as unlinked attachment to match during future sync
                existing_attachment = request.env['ir.attachment'].sudo().search([
                    ('res_model', '=', False),
                    ('name', '=', pdf_name)
                ], limit=1)
                if existing_attachment:
                    existing_attachment.write({
                        'datas': pdf_data,
                        'mimetype': 'application/pdf'
                    })
                    message = f'Unlinked PDF successfully replaced for Invoice stem: {pdf_stem}.'
                else:
                    request.env['ir.attachment'].sudo().create({
                        'name': pdf_name,
                        'type': 'binary',
                        'datas': pdf_data,
                        'res_model': False,
                        'res_id': False,
                        'mimetype': 'application/pdf'
                    })
                    message = f'Unlinked PDF successfully saved for Invoice stem: {pdf_stem}.'
                return {
                    'status': 'success',
                    'message': message
                }
                
            # 2. Check if a PDF attachment already exists for this invoice with the same name,
            # or any PDF attachment exists on this invoice
            existing_attachment = request.env['ir.attachment'].sudo().search([
                ('res_model', '=', 'account.move'),
                ('res_id', '=', invoice.id),
                ('name', '=', pdf_name)
            ], limit=1)
            
            if not existing_attachment:
                # Overwrite/Replace policy: if there is any PDF attachment on this invoice, replace it!
                existing_attachment = request.env['ir.attachment'].sudo().search([
                    ('res_model', '=', 'account.move'),
                    ('res_id', '=', invoice.id),
                    ('mimetype', '=', 'application/pdf')
                ], limit=1)
                
            if existing_attachment:
                # Overwrite/Replace old PDF file to free up storage space!
                existing_attachment.write({
                    'name': pdf_name,
                    'datas': pdf_data,
                    'mimetype': 'application/pdf'
                })
                message = f'PDF successfully replaced for Invoice {invoice.ref or invoice.name}.'
            else:
                # Create a new attachment
                request.env['ir.attachment'].sudo().create({
                    'name': pdf_name,
                    'type': 'binary',
                    'datas': pdf_data,
                    'res_model': 'account.move',
                    'res_id': invoice.id,
                    'mimetype': 'application/pdf'
                })
                message = f'PDF successfully created and attached to Invoice {invoice.ref or invoice.name}.'
                
            return {
                'status': 'success',
                'message': message
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Failed to process PDF attachment: {str(e)}'
            }

    @http.route('/wideorbit_sync/debug/decode', type='json', auth='public', methods=['POST'], csrf=False)
    def debug_decode(self, **kwargs):
        try:
            import base64
            import re
            log_record = request.env['rpa.sync.log'].sudo().search([('invoice_file', '!=', False)], limit=1, order='id desc')
            if not log_record:
                return {'status': 'error', 'message': 'No RPA log records found'}
            
            data = log_record.invoice_file
            
            t = str(type(data))
            length = len(data) if data else 0
            first_50 = str(data[:50]) if data else ''
            
            # Let's run safe_decode_base64 logic step-by-step and record outputs
            is_str_match = isinstance(data, str)
            is_bytes_match = isinstance(data, bytes)
            
            step_log = []
            decoded_magic = None
            exception_msg = None
            
            if isinstance(data, str):
                step_log.append("Matched isinstance(data, str)")
                try:
                    res = base64.b64decode(data.strip())
                    decoded_magic = str(res[:10])
                    step_log.append("Direct b64decode of str success")
                except Exception as e:
                    exception_msg = f"str b64decode error: {str(e)}"
            elif isinstance(data, bytes):
                step_log.append("Matched isinstance(data, bytes)")
                starts_with_pk = data.startswith(b'PK\x03\x04')
                step_log.append(f"starts_with_pk: {starts_with_pk}")
                
                try:
                    cleaned_data = re.sub(rb'\s+', b'', data)
                    step_log.append(f"cleaned_data len: {len(cleaned_data)}")
                    decoded = base64.b64decode(cleaned_data, validate=True)
                    decoded_magic = str(decoded[:10])
                    step_log.append("bytes b64decode with validate=True success")
                except Exception as e:
                    exception_msg = f"bytes b64decode error: {str(e)}"
            
            return {
                'status': 'success',
                'type': t,
                'length': length,
                'first_50': first_50,
                'is_str_match': is_str_match,
                'is_bytes_match': is_bytes_match,
                'step_log': step_log,
                'decoded_magic': decoded_magic,
                'exception_msg': exception_msg
            }
        except Exception as e:
            return {'status': 'error', 'message': str(e)}

    @http.route('/wideorbit_sync/debug/logs', type='json', auth='public', methods=['POST'], csrf=False)
    def debug_logs(self, **kwargs):
        try:
            logs = request.env['wideorbit.sync.log'].sudo().search_read([], limit=1, order='id desc')
            if logs:
                log = logs[0]
                return {
                    'status': 'success',
                    'sync_date': str(log.get('sync_date')),
                    'status_log': log.get('status'),
                    'invoices_processed': log.get('invoices_processed'),
                    'invoices_created': log.get('invoices_created'),
                    'invoices_updated': log.get('invoices_updated'),
                    'agencies_created': log.get('agencies_created'),
                    'advertisers_created': log.get('advertisers_created'),
                    'details': log.get('details'),
                }
            return {'status': 'error', 'message': 'No logs found'}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}

